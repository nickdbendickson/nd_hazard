# -*- coding: utf-8 -*-
"""The offline data pack builder of both dam suites (packbuild 1.1, suite 1.18.7).

ONE engine for the ND Dam Suite (nd_hazard: ND Dam Hazard Helper, ND Data Updater) and the
DamSafety suite (DWR_Plugins: DamSafety_Hazard, DamSafety_Data). Before 1.18.6 each plugin
carried its own build_nd_pack.py and the two had drifted apart (the DamSafety copy had the audit
fixes - tiled 3DHP listing, page anchors, HTTP 400 page shrinking, the DWR files; the ND copy had
the folder pack, 3DHP transforms, layer files, land cover and the SARP national download). This
module is both of them; each plugin's build_nd_pack.py is now a short shim that binds the
plugin's constants and osm_parse and then IS this module (sys.modules alias), so
`from <plugin> import build_nd_pack` and `python build_nd_pack.py ...` work as before.

    bind(constants, osm_parse)   the plugin's address book (URLs, workers, tile sizes, the
                                 data-source file overrides) and its Overpass parser; read at
                                 call time, so the data-source file still applies
    pack_layers()                "nd" or "dwr" - constants.PACK_LAYERS; picks the layer list
                                 (packbuild 1.1: the barrier and ND DEQ layers are one list,
                                 shared_datasets(); see below)
    build(out, ...)              the pack (folder of GeoPackages, or the one-file zip)
    main(argv)                   the command line (python build_nd_pack.py --help)

Edit shared/damsuite/packengine.py in DWR_Plugins only, then run tools/sync_damsuite.py (and
--write-pin); the vendored copies are checked byte for byte.

From the ND copy's text:
Run on any computer with internet access - QGIS is NOT needed, any Python
3.7+ works (QGIS's own Python too):

    python build_nd_pack.py                      -> ND_Dam_Suite_Pack/ here (2.24.0)
    python build_nd_pack.py --out D:/ND_Dam_Suite_Pack
    python build_nd_pack.py --out D:/nd_pack.zip (the one-file pack of older releases)
    python build_nd_pack.py --only nsi,usa --refresh    (update two data sets)
    python build_nd_pack.py --list               (what it downloads)

1.19.0 (builder 1.3): the whole pack from one run. Flowlines and waterbodies come from the USGS
3D Hydrography Program (3DHP_flowlines, 3DHP_waterbodies; they replace NHD_*), the aquatic
barrier layers from the SARP services behind tool.aquaticbarriers.org (SARP_dams,
SARP_surveyed_crossings), the DWR and HIFLD layers from the files in the suite data folder's
dwr/ and hifld/ (or --files; DWR_dams from the DWR service when there is no file) and the NLCD
2021 land cover from the MRLC web coverage service (needs GDAL: inside QGIS).
3DHP: the web service is read in 0.25 degree tiles (a state-wide request times out); when the National
Map's 3DHP national file (zip / gdb / gpkg) is in the suite data folder's 3dhp/ (or --files) the
flowlines and waterbodies are cut out of it instead.

2.35.11 (builder 1.4): two more barrier layers - SARP_unsurveyed_crossings (the inventory's
unsurveyed, modelled road-stream crossings, from its national road-crossings download: the
services above hold the surveyed ones only) and USGS_stream_crossings (the USGS Database of
Stream Crossings in the United States, the TIGER x NHD HR base those crossings are built on).

Packbuild 1.1 (suite 1.18.7): ONE list of the barrier and ND DEQ layers for both suites
(shared_datasets()): the SARP / NACC Aquatic Barrier Inventory as ABI_dams,
ABI_small_barriers_surveyed and ABI_road_crossings_unsurveyed (kind "abi", damsuite.abi - every
column kept, network and barrier_status added), USGS_stream_crossings and NDDEQ_landfills /
NDDEQ_source_water_protection_*. The ND pack's SARP_dams / SARP_surveyed_crossings /
SARP_unsurveyed_crossings are replaced by the ABI_* layers; the old names still answer (the pack
readers' aliases, hydro3dhp.ALIASES, and --only).

2.24.0: the pack is a folder with one GeoPackage per layer (damsuite.gpkgpack: manifest.json,
LAYERS.txt with each layer and its source, <theme>/<name>.gpkg). The downloads still go into
the working file first (<folder>_work/, resume as below); then every data set fetched in this
run (or missing from the folder) is written to its GeoPackage. Layers the folder holds that
this builder does not fetch (the DWR files, HIFLD layers, land cover added to the pack) are
kept. An --out ending in .zip writes the older one-file pack instead.

It fetches every data set the plugin downloads - for all of North Dakota
(its bounding box plus a 0.1 degree margin, so the plugin's 2-3 mile
searches still work at the state line) - from the same services, with the
same addresses (your data-source file is used when --sources names it),
and writes one SQLite file plus manifest.json into a zip. Copy the zip to
the offline computer and choose it on the plugin's Data & Output tab
(7. Offline data pack).

An interrupted build is resumed: the data sets already finished are kept
in <name>_work/ next to the zip (delete that folder to start over). Since
2.8.0 a data set that was in progress is continued too: every finished chunk
(a batch of object ids, an NSI / Overpass tile, a page) is stored at once, and
a rerun after Cancel, a crash or a failed data set fetches only what is
missing (--refresh fetches everything again).

Slow or overloaded services: the requests of a data set share one limiter.
When the service answers HTTP 429 / 503 / 504 (or times out) the number of
requests at once is halved (down to 1), every worker waits together (a
Retry-After header is honoured), and the number slowly recovers after
successes. Each wait is written to the log, and the progress message keeps
changing while waiting ("waiting on the service (HTTP 429), 3 of 6 workers
paused").

The plugin can also run this for you: Data & Output tab > Build offline
pack... (on a computer that is online).
"""

import argparse
import contextvars
import email.utils
import hashlib
import json
import math
import os
import random
import re
import socket
import sys
import threading
import time
import zipfile
import zlib
from concurrent.futures import ThreadPoolExecutor, wait as _cf_wait, FIRST_COMPLETED
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request

from . import hydro3dhp as H3
from . import packfiles as PF
from .netproxy import urlopen                   # QGIS's proxy setting applies (1.16.2)
from .offline_pack import (PackWriter, DB_NAME, MANIFEST_NAME, ND_BBOX,
                           DEFAULT_PAD_DEG, PackError, STATUS_PARTIAL,
                           write_clean_copy, geom_bbox)

PACKBUILD_VERSION = "1.1"


class _Bound(object):
    """A plugin module the engine reads through (bind()): attribute look-ups go to the module
    at call time, so the plugin's data-source overrides (constants.apply_source_overrides)
    reach the builder."""

    def __init__(self, what):
        self.__dict__["_what"] = what
        self.__dict__["_mod"] = None

    def __getattr__(self, key):
        mod = self.__dict__["_mod"]
        if mod is None:
            raise AttributeError("packengine: {} not bound - call bind() first ({})".format(
                self.__dict__["_what"], key))
        return getattr(mod, key)

    def __setattr__(self, key, value):          # a test that sets C.X sets the plugin's X
        mod = self.__dict__["_mod"]
        setattr(mod if mod is not None else self.__dict__, key, value)


C = _Bound("the plugin's constants")
O = _Bound("the plugin's osm_parse")
_SCRIPT = [False]                    # run from the command line: apply --sources here


def bind(constants, osm_parse, script=False):
    """Read the addresses / settings from `constants` and the Overpass parser `osm_parse` of
    the plugin. script: run as a command (the data-source file is applied by build())."""
    C.__dict__["_mod"] = constants
    O.__dict__["_mod"] = osm_parse
    _SCRIPT[0] = bool(script)


def bound():
    return C.__dict__["_mod"] is not None


HERE = os.path.dirname(os.path.abspath(__file__))
BUILDER_VERSION = "1.5"
NLCD_NAME = "NLCD_2021_landcover"


def _df():
    """damsuite.dwrfiles (the DWR GeoPackages / downloads), imported when first used: it needs
    suite_fill, which the ND plugins do not vendor (they read the DWR files via packfiles)."""
    from . import dwrfiles
    return dwrfiles


def _nsi_tile_deg():
    return C.DOWNLOAD_TILE_DEG                   # the plugin's tile size (the API is happy)


TIMEOUT_S = 180
RETRIES = 5
OVERPASS_TILE_DEG = 2.0
OVERPASS_TIMEOUT_S = 300
IDS_CHUNK = 1000                             # features per ArcGIS request (or less)
# failed requests in a row (no success between, all workers): the service is
# down. A single bad feature fails about one request per halving level with a
# success between, so concurrent descents never come near it.
OUTAGE_FAILS = 24
MAX_MISSING_SHARE = 0.01                     # more ArcGIS features missing: data set fails
# v2.8.0: throttling / visible retries
THROTTLE_CODES = (429, 503, 504)             # "slow down" answers of the services
RETRY_AFTER_MAX_S = 120                      # longest Retry-After that is obeyed
RECOVER_AFTER = 8                            # successes in a row that give back one request
HEARTBEAT_S = 5.0                            # progress is reported at least this often
_SLICE_S = 0.25                              # how often a waiting thread looks at Cancel
# 1.3 (Hazard 2.20.2 / Data 1.5.1): tiled object-id listing ("arcgis_tiled", the Data pack's
# 3DHP hydro). The id query of a whole state times out (HTTP 504) on 3DHP; a 0.3 x 0.2 degree
# box answers in seconds. A tile that fails is quartered (after a short pause) down to
# TILED_SPLIT_DEPTH levels; what still fails is an area another service can fill.
TILED_TILE_DEG = 0.25
TILED_SPLIT_DEPTH = 4                        # 0.25 deg -> 1/16 of it at the deepest
TILED_CHUNK = 250                            # features per request (long flowline geometry)
SPLIT_PAUSE_S = 2.0                          # pause before a failed box is split (x level)
# 1.3: a paged read answered HTTP 400 is tried again with smaller pages down to PAGE_MIN
PAGE_MIN = 100
PAGE_400_PAUSE_S = 10.0

# v2.6.2: set when the build is cancelled - every worker stops at its next
# request or back-off instead of running on (inside QGIS: until QGIS exits)
_CANCEL = threading.Event()


class BuildError(Exception):
    pass


class BuildCancelled(BuildError):
    pass


class _Health(object):
    """Failed requests in a row for one data set; too many = the service is
    down, and halving chunks would only multiply the failing requests."""

    def __init__(self, limit=OUTAGE_FAILS):
        self.lock = threading.Lock()
        self.fails = 0
        self.limit = limit

    def ok(self):
        with self.lock:
            self.fails = 0

    def failed(self):
        with self.lock:
            self.fails += 1
            return self.fails >= self.limit

    def down(self):
        with self.lock:
            return self.fails >= self.limit


def _check_cancel():
    if _CANCEL.is_set():
        raise BuildCancelled("cancelled")


_NET_ERRORS = (HTTPError, URLError, TimeoutError, OSError, ValueError, BuildError)


# ------------------------------------------------------ throttle / reporting --
class ServiceBusy(BuildError):
    """An HTTP 200 answer whose body is an ArcGIS error saying "slow down"."""

    def __init__(self, code, msg):
        BuildError.__init__(self, msg)
        self.code = code


def _backoff_s(kind, attempt):
    """Seconds to wait before try attempt + 2. kind: "busy" (429 / 503 / 504),
    "timeout", "error" (anything else)."""
    if kind == "busy":
        return 30 * (attempt + 1)
    if kind == "timeout":
        return 10 * (attempt + 1)
    return 4 * (attempt + 1)


def _retry_after_s(err):
    """Seconds asked for by a Retry-After header (number or HTTP date), capped
    at RETRY_AFTER_MAX_S; None when there is none / it cannot be read."""
    hdrs = getattr(err, "headers", None)
    if hdrs is None:
        hdrs = getattr(err, "hdrs", None)
    try:
        val = hdrs.get("Retry-After") if hdrs is not None else None
    except Exception:
        val = None
    if val is None:
        return None
    val = str(val).strip()
    try:
        sec = float(val)
    except ValueError:
        try:
            dt = email.utils.parsedate_to_datetime(val)
            if dt.tzinfo is None:
                import datetime
                dt = dt.replace(tzinfo=datetime.timezone.utc)
            sec = dt.timestamp() - time.time()
        except (TypeError, ValueError, IndexError, OverflowError):
            return None
    if sec != sec:                                   # NaN
        return None
    return min(max(sec, 1.0), float(RETRY_AFTER_MAX_S))


def _is_timeout(e):
    if isinstance(e, (TimeoutError, socket.timeout)):
        return True
    reason = getattr(e, "reason", None)
    if isinstance(reason, (TimeoutError, socket.timeout)):
        return True
    return "timed out" in str(reason if reason is not None else e).lower()


def _short(e):
    txt = str(getattr(e, "reason", None) or e)
    txt = " ".join(txt.split())
    return txt if len(txt) <= 80 else txt[:77] + "..."


class _Slot(object):
    __slots__ = ("epoch",)

    def __init__(self, epoch):
        self.epoch = epoch


class NetSession(object):
    """The requests of ONE data set: a shared limiter and the reporter of
    their waits (v2.8.0).

    * acquire() / release(): at most `limit` requests run at once. When the
      service pushes back (HTTP 429 / 503 / 504, a timeout) the limit is
      halved (not below 1) - once per "event", however many requests of the
      same round fail - and every worker waits for the SAME pause (the back-off,
      or the Retry-After the service asked for) instead of each backing off on
      its own. RECOVER_AFTER successes in a row give one request back.
    * Every wait is written to `log` once per event; while waiting, beat() (the
      thread that drives the progress bar calls it) reports what is going on
      through `on_beat(text)` at least every HEARTBEAT_S.
    Everything is thread safe. http_json finds the session of the running data
    set in _NET (a context variable set by the builder; a no-op when unset)."""

    def __init__(self, label, workers, log=None, on_beat=None, clock=None):
        self.label = label
        self.max = max(1, int(workers))
        self.limit = self.max
        self.active = 0
        self.blocked = 0                     # threads waiting to run a request
        self.epoch = 0
        self.streak = 0
        self.paused_until = 0.0
        self.reason = ""
        self.pushbacks = 0                   # events so far (for the summary)
        self.cond = threading.Condition()
        self._log = log
        self._log_lock = threading.Lock()
        self._on_beat = on_beat
        self._clock = clock or time.monotonic
        self._owner = threading.get_ident()
        self._last_beat = self._clock()

    # -- reporting ---------------------------------------------------------
    def emit(self, text):
        if self._log is None:
            return
        with self._log_lock:
            try:
                self._log("  {}: {}".format(self.label, text))
            except Exception:
                pass

    def status_text(self):
        now = self._clock()
        with self.cond:
            paused = now < self.paused_until
            if paused or self.blocked:
                return "waiting on the service ({}), {} of {} workers paused".format(
                    self.reason or "slow answers", max(1, self.blocked), self.max)
            if self.limit < self.max:
                return "service is busy - {} of {} requests at a time".format(
                    self.limit, self.max)
            return "waiting for the service to answer ({} request(s) running)".format(
                self.active)

    def touch(self):
        self._last_beat = self._clock()

    def beat(self, main=False):
        """Report the state through on_beat when nothing was reported for
        HEARTBEAT_S. Only the thread that owns the session (the one that
        drives the progress bar) reports, unless main=True. An exception from
        the callback (a cancel) propagates."""
        if self._on_beat is None:
            return
        if not main and threading.get_ident() != self._owner:
            return
        now = self._clock()
        if now - self._last_beat < HEARTBEAT_S:
            return
        self._last_beat = now
        self._on_beat(self.status_text())

    def set_workers(self, n):
        with self.cond:
            n = max(1, int(n))
            self.limit = min(self.limit, n) if self.limit < self.max else n
            self.max = n
            self.cond.notify_all()

    # -- the limiter -------------------------------------------------------
    def acquire(self):
        """Wait until the pause is over and fewer than `limit` requests run;
        cancel-aware. Returns the slot to hand to release()."""
        counted = False
        try:
            while True:
                with self.cond:
                    if self._clock() >= self.paused_until and self.active < self.limit:
                        self.active += 1
                        return _Slot(self.epoch)
                    if not counted:
                        counted = True
                        self.blocked += 1
                    delay = self.paused_until - self._clock()
                    self.cond.wait(_SLICE_S if delay <= 0 else min(_SLICE_S, delay))
                _check_cancel()
                self.beat()
        finally:
            if counted:
                with self.cond:
                    self.blocked -= 1

    def release(self, slot, ok=False, push=None):
        """A request ended. ok: it succeeded. push: the service pushed back -
        {"reason", "wait" (s), "retry_after" (s or None), "try" (the next try
        number, None when there is no retry), "of"}."""
        lines = []
        with self.cond:
            self.active = max(0, self.active - 1)
            if push is not None:
                self.pushbacks += 1
                first = slot is None or slot.epoch == self.epoch
                if first:
                    self.epoch += 1
                    self.streak = 0
                    new = max(1, self.limit // 2)
                    if new < self.limit:
                        self.limit = new
                        lines.append("service is busy - now {} request(s) at a time".format(new))
                ra = push.get("retry_after")
                wait = float(ra) if ra else float(push["wait"])
                until = self._clock() + wait + random.random()
                if until > self.paused_until:
                    self.paused_until = until
                    self.reason = push["reason"]
                if first and push.get("try"):
                    lines.insert(0, "{}, waiting {:.0f} s (try {} of {}){}".format(
                        push["reason"], wait, push["try"], push["of"],
                        " - as the service asked" if ra else ""))
            elif ok:
                self.streak += 1
                if self.limit < self.max and self.streak >= RECOVER_AFTER:
                    self.limit += 1
                    self.streak = 0
                    lines.append("service answers again - {} request(s) at a time".format(
                        self.limit))
            self.cond.notify_all()
        for ln in lines:
            self.emit(ln)

    def backoff(self, reason, wait, attempt, retries):
        """An error that is not a push-back: this worker alone waits (logged),
        cancel-aware."""
        self.emit("{}, waiting {:.0f} s (try {} of {})".format(reason, wait, attempt + 2,
                                                                 retries))
        with self.cond:
            self.blocked += 1
        try:
            self.sleep(wait)
        finally:
            with self.cond:
                self.blocked -= 1

    def sleep(self, seconds):
        end = self._clock() + seconds
        while True:
            _check_cancel()
            rem = end - self._clock()
            if rem <= 0:
                return
            if _CANCEL.wait(min(rem, _SLICE_S)):
                raise BuildCancelled("cancelled")
            self.beat()


_NET = contextvars.ContextVar("nd_pack_net", default=None)


# ------------------------------------------------------------------- HTTP --
def _ua():
    return C.HTTP_USER_AGENT + " offline-pack-builder/" + BUILDER_VERSION


def _sleep_plain(seconds):
    if _CANCEL.wait(seconds):
        raise BuildCancelled("cancelled")


def http_json(url, params=None, post=False, retries=RETRIES, what=""):
    """GET / POST and decode JSON, retried with back-off. An ArcGIS
    {"error": ...} answer is an error too. v2.8.0: inside a data set (a
    NetSession is set) the requests share a limiter, a push-back (429 / 503 /
    504 / timeout) lowers the number of requests at once and pauses all of
    them together (Retry-After honoured), and every wait is logged."""
    data = None
    full = url
    if params:
        enc = urlencode(params)
        if post:
            data = enc.encode("utf-8")
        else:
            full = url + ("&" if "?" in url else "?") + enc
    net = _NET.get()
    last = None
    for attempt in range(retries):
        _check_cancel()
        slot = net.acquire() if net is not None else None
        ok = False
        kind, reason, wait, retry_after, stop = None, "", 0.0, None, False
        more = attempt + 1 < retries
        try:
            try:
                req = Request(full, data=data, headers={
                    "User-Agent": _ua(), "Accept": "application/json, */*",
                    **({"Content-Type": "application/x-www-form-urlencoded"} if data else {})})
                with urlopen(req, timeout=TIMEOUT_S) as r:
                    raw = r.read()
                obj = json.loads(raw.decode("utf-8"))
                if isinstance(obj, dict) and "error" in obj:
                    err = obj["error"]
                    code = err.get("code") if isinstance(err, dict) else None
                    msg = "service error: {}".format(
                        err.get("message") if isinstance(err, dict) else err)
                    try:
                        code = int(code)
                    except (TypeError, ValueError):
                        code = None
                    if code in THROTTLE_CODES:
                        raise ServiceBusy(code, msg)
                    raise BuildError(msg)
                ok = True
                return obj
            except HTTPError as e:
                last = e
                reason = "HTTP {}".format(e.code)
                if e.code in THROTTLE_CODES:
                    kind = "busy"
                    retry_after = _retry_after_s(e)
                else:
                    kind = "error"
                if e.code in (400, 401, 403, 404) and attempt >= 1:
                    stop = True                         # will not get better
            except BuildCancelled:
                raise
            except ServiceBusy as e:
                last = e
                kind, reason = "busy", "HTTP {}".format(e.code)
            except _NET_ERRORS as e:
                last = e
                if _is_timeout(e):
                    kind, reason = "timeout", "timed out"
                else:
                    kind, reason = "error", _short(e)
            # the wait after a failed try (the last try does not wait, but a
            # push-back still slows the others down)
            wait = _backoff_s(kind, attempt if more else 0)
        finally:
            if net is not None:
                push = None
                if kind in ("busy", "timeout"):
                    push = {"reason": reason, "wait": wait, "retry_after": retry_after,
                            "try": attempt + 2 if (more and not stop) else None,
                            "of": retries}
                net.release(slot, ok=ok, push=push)
        if stop:
            break
        if more:                                    # v2.6.2: no sleep after the last try
            if net is None:
                _sleep_plain(wait + random.random())
            elif kind == "error":
                net.backoff(reason, wait, attempt, retries)
            # busy / timeout: the shared pause holds every worker (acquire)
    err = BuildError("{}{} ({})".format(what + ": " if what else "", url.split("?")[0], last))
    err.http_code = getattr(last, "code", None)          # 1.3: HTTP 400 on pages: smaller pages
    raise err


def _pool(ctx, workers, calls, on_result):
    """Run calls [(fn, args)] on a thread pool; on_result(args, result or
    exception) runs on this thread as each finishes. A cancel (an exception
    from the progress callback) drops the calls not started yet at once.
    v2.8.0: this thread also keeps the progress bar alive while every worker
    waits on the service (NetSession.beat), and the workers see the data
    set's NetSession."""
    net = _NET.get()
    if net is not None:
        net.set_workers(workers)
    ex = ThreadPoolExecutor(max_workers=max(1, workers))
    futs, order = {}, {}
    for fn, args in calls:
        fu = ex.submit(contextvars.copy_context().run, fn, *args)
        futs[fu] = args
        order[fu] = len(order)
    pending = set(futs)
    tick = max(0.01, min(1.0, HEARTBEAT_S))
    try:
        while pending:
            done, pending = _cf_wait(pending, timeout=tick, return_when=FIRST_COMPLETED)
            if not done:
                if net is not None:
                    net.beat(main=True)
                continue
            for fu in sorted(done, key=order.get):     # first come, first stored
                try:
                    res = fu.result()
                except BuildCancelled:
                    raise
                except _NET_ERRORS as e:
                    res = e
                on_result(futs[fu], res)
            if net is not None:
                net.touch()
    except BaseException:
        _CANCEL.set()                      # running workers stop at their next request
        try:
            ex.shutdown(wait=False, cancel_futures=True)
        except TypeError:                               # Python < 3.9
            for fu in futs:
                fu.cancel()
            ex.shutdown(wait=False)
        raise
    ex.shutdown(wait=True)


# ---------------------------------------------------------------- ArcGIS --
def _envelope(b):
    return {"geometry": "{},{},{},{}".format(*b), "geometryType": "esriGeometryEnvelope",
            "inSR": "4326", "spatialRel": "esriSpatialRelIntersects"}


def _split4(b):
    x0, y0, x1, y1 = b
    xm, ym = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    return [(x0, y0, xm, ym), (xm, y0, x1, ym), (x0, ym, xm, y1), (xm, ym, x1, y1)]


def arcgis_ids(url, bbox, where="1=1", depth=0):
    """Every object id in the box (the box is split when the service will
    not list them all at once)."""
    try:
        d = http_json(url.rstrip("/") + "/query", dict(_envelope(bbox), where=where,
                                                         returnIdsOnly="true", f="json"),
                      post=True, retries=3 if depth else RETRIES, what="object ids")
        ids = d.get("objectIds") or []
        return set(int(i) for i in ids)
    except BuildCancelled:
        raise
    except BuildError:
        # 1.19.0: a slow service (3DHP: HTTP 504 for a whole-state id list) answers a smaller box -
        # split sooner and deeper (4^5 boxes at most)
        if depth >= 5:
            raise
        out = set()
        for q in _split4(bbox):
            out |= arcgis_ids(url, q, where, depth + 1)
        return out


def _arcgis_chunk(url, ids, out_fields, precision, retries=RETRIES):
    params = {"objectIds": ",".join(str(i) for i in ids), "outFields": out_fields,
              "outSR": "4326", "returnGeometry": "true", "f": "geojson"}
    if precision is not None:
        params["geometryPrecision"] = str(precision)
    d = http_json(url.rstrip("/") + "/query", params, post=True, retries=retries,
                  what="features")
    return d.get("features", []) if isinstance(d, dict) else []


def _arcgis_chunk_split(url, ids, out_fields, precision, missing, health=None, depth=0):
    """A chunk; a failing chunk is halved until the single failing features
    are known. v2.6.2: the halves are tried once each (not with the full
    retries), and when the service keeps failing (health) the rest of the
    chunk is given up at once instead of halving into thousands of requests."""
    health = health or _Health()
    if health.down():
        missing.extend(ids)
        return []
    try:
        feats = _arcgis_chunk(url, ids, out_fields, precision,
                              retries=RETRIES if depth == 0 else 1)
        health.ok()
        return feats
    except BuildCancelled:
        raise
    except BuildError:
        if health.failed() or len(ids) == 1:
            missing.extend(ids)
            return []
        h = len(ids) // 2
        return (_arcgis_chunk_split(url, ids[:h], out_fields, precision, missing, health,
                                    depth + 1) +
                _arcgis_chunk_split(url, ids[h:], out_fields, precision, missing, health,
                                    depth + 1))


# ------------------------------------------------------- chunk-level resume --
# A data set is fetched in chunks; every finished chunk is stored at once with
# a key (PackWriter.add(chunk=key)), and a rerun after Cancel / crash / failure
# fetches only the chunks that are not stored. A chunk is keyed by WHAT it
# holds - the object ids of an ArcGIS batch, the box of a tile, the offset of
# a page - so an id list that changed between runs never skips a chunk wrongly.
def _ids_key(ids):
    crc = zlib.crc32(",".join(str(i) for i in ids).encode("ascii")) & 0xffffffff
    return "ids:{}:{}:{}:{:08x}".format(ids[0], ids[-1], len(ids), crc)


def _pack_json(obj):
    return zlib.compress(json.dumps(obj, separators=(",", ":")).encode("utf-8"), 6)


def _unpack_json(blob):
    try:
        return json.loads(zlib.decompress(blob).decode("utf-8"))
    except (TypeError, ValueError, zlib.error):
        return None


def _tile_key(t):
    return "tile:{:.6f},{:.6f},{:.6f},{:.6f}".format(*t)


def _resume_ids(ctx, ids, prefix="ids:", ignore=()):
    """The object ids already stored (chunks kept from an earlier run that are
    still valid for `ids`). A stored chunk holding an id the service no longer
    lists (features deleted meanwhile) is dropped whole - its remaining ids
    are fetched again, so the result is what the service lists now. 1.3:
    prefix = the key start of these chunks; keys starting with one of `ignore`
    belong to another part of the same data set (arcgis_tiled: the fill
    service) and are left alone."""
    w = ctx.writer
    kept = w.chunks()
    if not kept:
        return set()
    listed = set(ids)
    done, stale = set(), []
    for key, blob in kept.items():
        if ignore and key.startswith(tuple(ignore)):
            continue
        cids = _unpack_json(blob) if key.startswith(prefix) and blob else None
        if not isinstance(cids, list) or not all(i in listed for i in cids):
            stale.append(key)
        else:
            done.update(cids)
    if stale:
        w.drop_chunks(stale)
        ctx.log("  the service's feature list changed since the earlier run - {} stored "
                "batch(es) are read again".format(len(stale)))
    if done:
        ctx.log("  resuming: {:,} of {:,} features already stored".format(len(done), len(ids)))
    return done


def _resume_tiles(ctx, tiles):
    """(keys of the tiles already stored, key of every tile). Tiles share
    features along their edges, so when the earlier run used other tiles the
    data set starts over."""
    keys = [_tile_key(t) for t in tiles]
    kept = ctx.writer.chunks()
    if not kept:
        return set(), keys
    if any(k not in set(keys) for k in kept):
        ctx.log("  the earlier partial download used other tiles - starting over")
        ctx.writer.restart_stage()
        return set(), keys
    ctx.log("  resuming: {} of {} tiles already stored".format(len(kept), len(tiles)))
    return set(kept), keys


def _arcgis_chunk_job(url, ids, out_fields, precision, health):
    """One batch of ids on a worker: (features, ids that could not be read)."""
    miss = []
    feats = _arcgis_chunk_split(url, ids, out_fields, precision, miss, health)
    return feats, miss


def _uid_arcgis(oid_field):
    low = (oid_field or "").lower()

    def uid(f):
        if f.get("id") is not None:
            return f["id"]
        props = f.get("properties") or {}
        for k, v in props.items():
            if k.lower() in (low, "objectid", "fid", "oid"):
                return v
        return None
    return uid


def _fetch_id_chunks(ctx, url, ids, done_ids, size, out_fields, precision, uid,
                     prefix="", edit=None, progress=None):
    """The features of `ids` (not in done_ids) in parallel chunks of `size`, each finished
    chunk stored with its key (prefix + ids key). 1.3: edit(features) -> the features to
    store (arcgis_tiled: tag / filter them); progress(done, total) instead of ctx.sub.
    Returns (ids not read, health)."""
    todo = [i for i in ids if i not in done_ids]
    chunks = [todo[i:i + size] for i in range(0, len(todo), size)]
    missing = []
    finished = [len(done_ids)]
    health = _Health()
    show = progress or (lambda k, n: ctx.sub(100.0 * k / max(1, n), "{:,} of {:,} features".format(
        min(n, k), n)))
    if done_ids:
        show(len(done_ids), len(ids))

    def got(args, res):
        ch = args[1]
        if isinstance(res, Exception):
            missing.extend(ch)
        else:
            feats, miss = res
            if edit is not None:
                feats = edit(feats)
            if miss:                # not wholly read: no chunk record - read again next run
                missing.extend(miss)
                ctx.writer.add(feats, uid)
            else:
                ctx.writer.add(feats, uid, chunk=prefix + _ids_key(ch), payload=_pack_json(ch))
        finished[0] += len(ch)
        show(finished[0], len(ids))
    _pool(ctx, ctx.workers, [(_arcgis_chunk_job, (url, ch, out_fields, precision, health))
                             for ch in chunks], got)
    return missing, health


def _known_fields(info, out_fields, log):
    """1.19.0: the wanted fields the layer really has (a field list written for one service
    version must not fail the whole layer); "*" stays."""
    if not out_fields or out_fields == "*":
        return "*"
    have = {str(f.get("name")).lower(): f.get("name") for f in info.get("fields") or []}
    if not have:
        return out_fields
    want = [x.strip() for x in out_fields.split(",") if x.strip()]
    keep = [have[x.lower()] for x in want if x.lower() in have]
    lost = [x for x in want if x.lower() not in have]
    if lost:
        log("  fields the layer does not have (left out): {}".format(", ".join(lost)))
    return ",".join(keep) if keep else "*"


def _grid(b, n):
    x0, y0, x1, y1 = b
    dx, dy = (x1 - x0) / n, (y1 - y0) / n
    return [(x0 + i * dx, y0 + j * dy, x0 + (i + 1) * dx, y0 + (j + 1) * dy)
            for j in range(n) for i in range(n)]


def _arcgis_tile_job(url, tile, oid, size, out_fields, precision):
    """One tile on a worker: every feature touching the box, paged by offset."""
    feats, offset = [], 0
    while True:
        params = dict(_envelope(tile), where="1=1", outFields=out_fields, outSR="4326",
                      f="geojson", resultOffset=offset, resultRecordCount=size)
        if oid:
            params["orderByFields"] = "{} ASC".format(oid)
        if precision is not None:
            params["geometryPrecision"] = str(precision)
        d = http_json(url.rstrip("/") + "/query", params, post=True, retries=RETRIES + 3,
                      what="tile")
        page = d.get("features", []) if isinstance(d, dict) else []
        feats.extend(page)
        exceeded = bool(d.get("exceededTransferLimit") or
                        (d.get("properties") or {}).get("exceededTransferLimit"))
        if not page or (len(page) < size and not exceeded):
            return feats
        offset += len(page)


def fetch_arcgis_tiles(ctx, url, bbox, tile_deg, out_fields="*", precision=None,
                       transform=None):
    """1.19.0: a heavy layer (3DHP: HTTP 504 for a state-wide id list, but small boxes answer) is read
    in tiles of tile_deg degrees, each tile paged by offset; a tile that touches two boxes is kept
    once (the feature id). A finished tile is stored at once, so a rerun reads only what is missing."""
    info = http_json(url.rstrip("/"), {"f": "json"}, what="layer description")
    out_fields = _known_fields(info, out_fields, ctx.log)
    transform = transform or (lambda feats: feats)
    oid = info.get("objectIdField") or next(
        (f.get("name") for f in info.get("fields") or []
         if f.get("type") == "esriFieldTypeOID"), None)
    size = max(1, min(1000, int(info.get("maxRecordCount") or 1000)))
    uid = _uid_arcgis(oid)
    tiles = _tiles(bbox, tile_deg)
    ctx.log("  {} tiles of {} degree".format(len(tiles), tile_deg))
    have, keys = _resume_tiles(ctx, tiles)
    failed = []
    done = [len(have)]

    def got(args, res):
        if isinstance(res, Exception):
            failed.append((args[1], str(res)))
        else:
            ctx.writer.add(transform(res), uid, chunk=_tile_key(args[1]))
        done[0] += 1
        ctx.sub(100.0 * done[0] / len(tiles), "{} of {} tiles, {:,} features".format(
            done[0], len(tiles), ctx.writer.count))
    _pool(ctx, ctx.workers, [(_arcgis_tile_job, (url, t, oid, size, out_fields, precision))
                             for t, k in zip(tiles, keys) if k not in have], got)
    if failed:
        if len(failed) > max(2, len(tiles) // 20):
            raise BuildError("{} of {} tiles failed, e.g. {}".format(
                len(failed), len(tiles), failed[0][1]))
        note = "{} tile(s) could not be read: {}".format(len(failed), "; ".join(
            "{:.2f},{:.2f}".format(t[0], t[1]) for t, _e in failed))
        ctx.log("  WARNING: " + note)
        ctx.gaps = [tuple(t) for t, _e in failed]
        ctx.status = STATUS_PARTIAL
        return note
    return ""


def fetch_arcgis(ctx, url, bbox, out_fields="*", precision=None, transform=None, id_grid=1,
                 tile_deg=None):
    """Whole-area ArcGIS layer: the object ids first, then the features by
    id in parallel chunks. Services that cannot list ids are paged by
    offset. Returns a note. transform(features) -> features is applied to
    every batch before it is stored (3DHP: the NHD-style properties).
    tile_deg: read in tiles of that size instead (see fetch_arcgis_tiles)."""
    if tile_deg:
        return fetch_arcgis_tiles(ctx, url, bbox, tile_deg, out_fields, precision, transform)
    info = http_json(url.rstrip("/"), {"f": "json"}, what="layer description")
    out_fields = _known_fields(info, out_fields, ctx.log)
    oid = info.get("objectIdField") or next(
        (f.get("name") for f in info.get("fields") or []
         if f.get("type") == "esriFieldTypeOID"), None)
    mrc = int(info.get("maxRecordCount") or IDS_CHUNK)
    size = max(1, min(IDS_CHUNK, mrc))
    uid = _uid_arcgis(oid)
    try:
        if id_grid > 1:             # 1.19.0: a heavy layer (3DHP) times out on the whole state
            found = set()
            boxes = _grid(bbox, id_grid)
            for k, q in enumerate(boxes):
                ctx.sub(0.0, "listing features, area {} of {}".format(k + 1, len(boxes)))
                found |= arcgis_ids(url, q)
            ids = sorted(found)
        else:
            ids = sorted(arcgis_ids(url, bbox))
    except BuildCancelled:
        raise
    except BuildError as e:
        ctx.log("  object ids not listed ({}) - reading pages instead".format(e))
        return _fetch_arcgis_pages(ctx, url, bbox, oid, mrc, out_fields, precision, uid,
                                   edit=(info.get("editingInfo") or {}).get("lastEditDate"),
                                   why=_short(e), transform=transform)
    done_ids = _resume_ids(ctx, ids)
    ctx.log("  {:,} features".format(len(ids)))
    if not ids:
        return "none in the area"
    missing, health = _fetch_id_chunks(ctx, url, ids, done_ids, size, out_fields, precision,
                                       uid, edit=transform)
    n = ctx.writer.count
    note = ""
    if health.down():
        raise BuildError("the service stopped answering ({} requests failed in a row) - "
                         "{:,} of {:,} features read".format(health.limit, n, len(ids)))
    if missing or n < len(ids):
        lost = len(missing) or len(ids) - n
        note = "{:,} of {:,} features ({} could not be read)".format(n, len(ids), lost)
        ctx.log("  WARNING: " + note)
        # v2.6.2: never "complete" with features missing - where they are is
        # unknown, so the plugin uses this data set only when the service
        # cannot be reached, with a warning; many missing: it fails (retried
        # on the next build, the NID mirror is tried)
        if lost > max(1, MAX_MISSING_SHARE * len(ids)):
            raise BuildError(note)
        ctx.status = STATUS_PARTIAL
    return note


# ------------------------------------------------- tiled ArcGIS (1.3) --
TILED_TILE_FAILS = 12                        # failed requests in a row inside one tile
TILED_DOWN_TILES = 6                         # tiles in a row with nothing listed: service down


def _pause(seconds):
    """Cancel-aware wait (through the data set's NetSession when there is one)."""
    if seconds <= 0:
        return
    net = _NET.get()
    if net is not None:
        net.sleep(seconds)
    else:
        _sleep_plain(seconds)


def _list_ids_split(url, box, max_depth, budget, where="1=1", depth=0):
    """1.3: the object ids of `box`, split on failure. Returns (leaves, failed): leaves =
    [(box, [ids])] of the parts the service listed, failed = [box] of the parts it would not
    list (HTTP 504 / time-outs / errors) even when quartered max_depth times. A failed box
    waits SPLIT_PAUSE_S x level before it is split (back-off); budget (a _Health) stops the
    splitting once the tile has failed too often in a row (its remaining parts: failed)."""
    if budget.down():
        return [], [tuple(box)]
    try:
        d = http_json(url.rstrip("/") + "/query", dict(_envelope(box), where=where,
                                                         returnIdsOnly="true", f="json"),
                      post=True, retries=3 if depth == 0 else 2, what="object ids")
    except BuildCancelled:
        raise
    except BuildError as e:
        budget.failed()
        budget.last = _reason(e)
        if depth >= max_depth or budget.down():
            return [], [tuple(box)]
        _pause(SPLIT_PAUSE_S * (depth + 1))
        leaves, failed = [], []
        for q in _split4(box):
            a, b = _list_ids_split(url, q, max_depth, budget, where, depth + 1)
            leaves += a
            failed += b
        return leaves, failed
    budget.ok()
    ids = (d.get("objectIds") if isinstance(d, dict) else None) or []
    return [(tuple(box), sorted(int(i) for i in ids))], []


def _reason(e):
    """1.3: the short cause of a failed request ("HTTP Error 504: Gateway Time-out")."""
    txt = str(e)
    for pat in (r"HTTP Error \d+[^()]*", r"timed out", r"service error: [^()]*"):
        m = re.search(pat, txt)
        if m:
            return m.group(0).strip().rstrip(")")
    return _short(e)


def _list_ids_tiled(ctx, url, tiles, max_depth, what):
    """1.3: every tile listed in parallel (split on failure). Returns (leaves, failed,
    {cause: failed requests})."""
    leaves, failed, causes = [], [], {}
    state = {"bad_row": 0, "done": 0}
    lock = threading.Lock()

    def job(tile):
        with lock:
            down = state["bad_row"] >= TILED_DOWN_TILES
        if down:                            # the service is down: no more requests
            return [], [tuple(tile)], "service not answering"
        budget = _Health(limit=TILED_TILE_FAILS)
        budget.last = ""
        a, b = _list_ids_split(url, tile, max_depth, budget)
        with lock:
            state["bad_row"] = 0 if a else state["bad_row"] + 1
        return a, b, budget.last

    def got(args, res):
        if isinstance(res, Exception):
            failed.append(tuple(args[0]))
            why = _reason(res)
        else:
            leaves.extend(res[0])
            failed.extend(res[1])
            why = res[2] if res[1] else ""
        if why:
            causes[why] = causes.get(why, 0) + 1
        state["done"] += 1
        ctx.sub(20.0 * state["done"] / max(1, len(tiles)), "{}: listing area {} of {}".format(
            what, state["done"], len(tiles)))
    _pool(ctx, ctx.workers, [(job, (t,)) for t in tiles], got)
    return leaves, failed, causes


class _BoxIndex(object):
    """1.3: which of many small boxes holds a point / meets a box (grid of cells)."""

    def __init__(self, boxes, cell=TILED_TILE_DEG):
        self.boxes = [tuple(b) for b in boxes]
        self.cell = float(cell)
        self.grid = {}
        for k, b in enumerate(self.boxes):
            for c in self._cells(b):
                self.grid.setdefault(c, []).append(k)

    def _cells(self, b):
        c = self.cell
        for i in range(int(math.floor(b[0] / c)), int(math.floor(b[2] / c)) + 1):
            for j in range(int(math.floor(b[1] / c)), int(math.floor(b[3] / c)) + 1):
                yield (i, j)

    def __bool__(self):
        return bool(self.boxes)

    def holds(self, x, y):
        c = self.cell
        for k in self.grid.get((int(math.floor(x / c)), int(math.floor(y / c))), ()):
            b = self.boxes[k]
            if b[0] <= x < b[2] and b[1] <= y < b[3]:
                return True
        return False

    def meets(self, bb):
        for cell in self._cells(bb):
            for k in self.grid.get(cell, ()):
                b = self.boxes[k]
                if b[0] <= bb[2] and bb[0] <= b[2] and b[1] <= bb[3] and bb[1] <= b[3]:
                    return True
        return False


def _owned(bb, area, index):
    """1.3: does the region of `index` own a feature with bounding box bb? Its centre lies
    in one of the boxes, or (centre outside the whole area) it touches one."""
    cx, cy = (bb[0] + bb[2]) / 2.0, (bb[1] + bb[3]) / 2.0
    if index.holds(cx, cy):
        return True
    inside = area[0] <= cx <= area[2] and area[1] <= cy <= area[3]
    return not inside and index.meets(bb)


def _tagged_uid(tag, uid):
    """1.3: "<tag>:<id>" - object ids of two services collide; no id: the geometry hash."""
    def f(feat):
        u = uid(feat)
        if u is None:
            g = feat.get("geometry")
            u = "g:" + hashlib.sha1(json.dumps(g, sort_keys=True).encode("utf-8"), usedforsecurity=False).hexdigest()
        return "{}:{}".format(tag, u)
    return f


def _layer_oid(info):
    oid = info.get("objectIdField") or next(
        (f.get("name") for f in info.get("fields") or []
         if f.get("type") == "esriFieldTypeOID"), None)
    mrc = int(info.get("maxRecordCount") or IDS_CHUNK)
    return oid, mrc


def _read_part(ctx, url, boxes, spec, tag, prefix, ignore, keep=None, first=0.0):
    """1.3: one service's part of an arcgis_tiled data set - the ids of `boxes` (split on
    failure), then the features in chunks. Returns (failed boxes, leaves [(box, ids)], ids not
    read, error text or "")."""
    try:
        info = http_json(url.rstrip("/"), {"f": "json"}, what="layer description")
    except BuildCancelled:
        raise
    except BuildError as e:
        ctx.log("  {}: the layer description failed ({}) - none of its {} area(s) read".format(
            tag, _short(e), len(boxes)))
        return [tuple(b) for b in boxes], [], [], "layer description: " + _reason(e)
    oid, mrc = _layer_oid(info)
    leaves, failed, causes = _list_ids_tiled(ctx, url, boxes, int(spec.get(
        "split_depth", TILED_SPLIT_DEPTH)), tag)
    ids = sorted(set(i for _b, ii in leaves for i in ii))
    ctx.log("  {}: {:,} features in {} area(s) listed, {} area(s) not listed".format(
        tag, len(ids), len(leaves), len(failed)))
    done = _resume_ids(ctx, ids, prefix=prefix, ignore=ignore)
    field = spec.get("source_field") or "src"

    def edit(feats):
        out = []
        for f in feats:
            if keep is not None:
                g = f.get("geometry") if isinstance(f, dict) else None
                bb = geom_bbox(g) if g else None
                if bb is None or not keep(bb):
                    continue
            props = f.get("properties")
            if not isinstance(props, dict):
                props = f["properties"] = {}
            props[field] = tag
            out.append(f)
        return out

    def show(k, n):
        ctx.sub(first + 20.0 + 40.0 * k / max(1, n), "{}: {:,} of {:,} features".format(
            tag, min(k, n), n))
    size = max(1, min(int(spec.get("chunk") or TILED_CHUNK), mrc))
    # prefix + "ids:..." keys (the fill part's prefix names its areas: other areas - stale)
    missing, _h = _fetch_id_chunks(ctx, url, ids, done, size, spec.get("fields", "*"),
                                   spec.get("precision"), _tagged_uid(tag, _uid_arcgis(oid)),
                                   prefix=prefix if prefix != "ids:" else "", edit=edit,
                                   progress=show)
    why = ", ".join("{} x{}".format(k, v) if v > 1 else k for k, v in sorted(
        causes.items(), key=lambda kv: -kv[1]))
    return failed, leaves, missing, why


def _boxes_key(boxes):
    txt = ";".join("{:.5f},{:.5f},{:.5f},{:.5f}".format(*b) for b in sorted(boxes))
    return "{:08x}".format(zlib.crc32(txt.encode("ascii")) & 0xffffffff)


def _reconcile(ctx, area, nhd_index, tag, fill_tag):
    """1.3: one source per place. Rows of `tag` owned by the fill region and rows of
    fill_tag outside it are removed; the chunk records of removed rows are dropped too, so a
    later run reads them again when its areas differ. Returns rows removed."""
    w = ctx.writer
    table = w._cur["table"]
    drop = []
    for fid, uid, x0, y0, x1, y1 in w.con.execute(
            "SELECT fid, uid, minx, miny, maxx, maxy FROM {}".format(table)):
        mine = _owned((x0, y0, x1, y1), area, nhd_index) if nhd_index else False
        src = str(uid).split(":", 1)[0]
        if (src == tag and mine) or (src == fill_tag and not mine):
            drop.append(fid)
    if not drop:
        return 0
    name = w._cur["name"]
    spans = list(w.con.execute("SELECT ckey, fid_lo, fid_hi FROM chunks WHERE name=?",
                               (name,)))
    hit = set()
    for fid in drop:
        for key, lo, hi in spans:
            if lo is not None and hi is not None and lo < fid <= hi:
                hit.add(key)
    for k in range(0, len(drop), 500):
        part = drop[k:k + 500]
        w.con.execute("DELETE FROM {} WHERE fid IN ({})".format(table, ",".join("?" * len(part))),
                      part)
    for key in hit:
        w.con.execute("DELETE FROM chunks WHERE name=? AND ckey=?", (name, key))
    w._cur["n"] = w.con.execute("SELECT COUNT(*) FROM {}".format(table)).fetchone()[0]
    w.con.commit()
    return len(drop)


def _count_tag(ctx, tag):
    w = ctx.writer
    return w.con.execute("SELECT COUNT(*) FROM {} WHERE uid LIKE ?".format(w._cur["table"]),
                         (tag + ":%",)).fetchone()[0]


def _round_box(b):
    return [round(float(v), 5) for v in b]


def fetch_arcgis_tiled(ctx, url, bbox, spec):
    """1.3 (Data 1.5.1, 3DHP hydro): an ArcGIS layer read area by area, another service
    filling only the areas it cannot serve.

    The object ids are listed per TILED_TILE_DEG tile (a tile that fails - HTTP 504, time-out
    - is quartered after a pause, down to split_depth levels), then the features are read in
    chunks. The areas whose ids could not be listed, or holding features that could not be
    read, are then read from spec["fill"] (another ArcGIS layer, e.g. NHD, listed and split
    the same way). Every feature carries properties[source_field] = its source tag, and its
    uid is "<tag>:<id>". One source per place: a feature belongs to the fill service when the
    centre of its bounding box lies in a fill area (or lies outside the whole area and the
    feature touches a fill area); features of the other source there are removed, so tile
    edges are not doubled. Fill areas the fill service cannot read either are the data set's
    gaps (status partial). ctx.tiled gets the per-area report (counts per source, the failed
    areas). Returns a note."""
    tag = spec.get("tag") or "main"
    fill = spec.get("fill") or None
    if fill:
        fill = dict(fill, source_field=fill.get("source_field") or spec.get("source_field"))
    ftag = (fill or {}).get("tag") or "fill"
    tiles = _tiles(bbox, float(spec.get("tile_deg") or TILED_TILE_DEG))
    rep = {"tiles": len(tiles), "source": tag, "fill_source": ftag if fill else None}
    ctx.tiled = rep
    ctx.log("  {}: {} area(s) of {} degree".format(tag, len(tiles),
                                                 spec.get("tile_deg") or TILED_TILE_DEG))
    failed, leaves, missing, err = _read_part(ctx, url, tiles, spec, tag, "ids:", ("fill:",))
    fill_boxes = list(failed)
    if missing:
        miss = set(missing)
        fill_boxes += [b for b, ii in leaves if any(i in miss for i in ii)]
    fill_boxes = sorted(set(tuple(b) for b in fill_boxes))
    rep.update(areas_listed=len(leaves), areas_not_listed=len(failed),
               missing_ids=len(missing), error=err or None)
    if failed or missing:
        why = []
        if failed:
            why.append("{} area(s) not listed{}".format(len(failed), " ({})".format(err)
                                                        if err else ""))
        if missing:
            why.append("{:,} feature(s) not read".format(len(missing)))
        rep["why"] = "; ".join(why)
        ctx.log("  {}: {} - {} area(s) to fill{}".format(
            tag, rep["why"], len(fill_boxes), " from " + ftag if fill else ""))
    gaps, nhd_ok = list(fill_boxes), []
    if fill_boxes and fill:
        furl = fill["url"]
        index = _BoxIndex(fill_boxes)
        ctx.log("  {} fill: reading {} area(s) from {}".format(ftag, len(fill_boxes), furl))
        net = NetSession(fill.get("label") or "{} fill".format(ftag), ctx.workers, log=ctx.log,
                         on_beat=getattr(ctx, "beat", None))
        token = _NET.set(net)
        try:
            f_failed, f_leaves, f_missing, f_err = _read_part(
                ctx, furl, fill_boxes, fill, ftag, "fill:{}:".format(_boxes_key(fill_boxes)),
                ("ids:",), keep=lambda bb: _owned(bb, bbox, index), first=40.0)
        finally:
            _NET.reset(token)
        fmiss = set(f_missing)
        nhd_ok = [b for b, ii in f_leaves if not any(i in fmiss for i in ii)]
        gaps = sorted(set(tuple(b) for b in f_failed) |
                      set(b for b, ii in f_leaves if any(i in fmiss for i in ii)))
        rep.update(fill_areas_read=len(nhd_ok), fill_missing_ids=len(f_missing),
                   fill_error=f_err or None)
        ctx.log("  {} fill: {} of {} area(s) read{}".format(
            ftag, len(nhd_ok), len(f_failed) + len(f_leaves),
            "" if not gaps else " - {} area(s) not read by either service".format(len(gaps))))
    removed = _reconcile(ctx, bbox, _BoxIndex(nhd_ok), tag, ftag)
    n_main, n_fill = _count_tag(ctx, tag), _count_tag(ctx, ftag)
    rep.update(count={tag: n_main, ftag: n_fill}, removed_overlap=removed,
               fill_areas=[_round_box(b) for b in fill_boxes],
               gap_areas=[_round_box(b) for b in gaps])
    if not leaves and not nhd_ok:
        raise BuildError("{} and {} both failed for the whole area ({}{})".format(
            tag, ftag if fill else "no fill service", err or "nothing listed",
            "; " + rep.get("fill_error") if rep.get("fill_error") else ""))
    ctx.gaps = [tuple(b) for b in gaps]
    if gaps:
        ctx.status = STATUS_PARTIAL
    if not fill_boxes:
        return "{:,} features from {} ({} areas)".format(n_main, tag, len(tiles))
    return "{:,} features from {}, {:,} from {} in {} of {} area(s){}".format(
        n_main, tag, n_fill, ftag, len(nhd_ok) if fill else 0, len(fill_boxes),
        "; {} area(s) not read".format(len(gaps)) if gaps else "")


def _page_anchor(url, bbox, oid, edit=None):
    """BP.1: what the paged service holds now - {"count", "max_oid", "edit"}
    (the parts it answers), or None when not even the count can be read."""
    try:
        d = http_json(url.rstrip("/") + "/query", dict(_envelope(bbox), where="1=1",
                      returnCountOnly="true", f="json"), post=True, retries=1,
                      what="feature count")
        a = {"count": int(d["count"])}
    except BuildCancelled:
        raise
    except Exception:                                  # noqa: BLE001 - best effort
        return None
    if oid:
        try:
            d = http_json(url.rstrip("/") + "/query", dict(_envelope(bbox), where="1=1",
                          outStatistics=json.dumps([{"statisticType": "max",
                                                     "onStatisticField": oid,
                                                     "outStatisticFieldName": "mx"}]),
                          f="json"), post=True, retries=1, what="last object id")
            attrs = (d.get("features") or [{}])[0].get("attributes") or {}
            mx = next((v for k, v in attrs.items() if k.lower() == "mx"), None)
            if mx is not None:
                a["max_oid"] = mx
        except BuildCancelled:
            raise
        except Exception:                              # noqa: BLE001
            pass
    if edit is not None:
        a["edit"] = edit
    return a


def _page_400(ctx, url, params, size, offset, err, why=""):
    """1.3: a page the service refused with HTTP 400 (FEMA USA_Structures while its object-id
    query answered "Invalid URL"): tried again after a pause with smaller pages (down to
    PAGE_MIN). Returns (answer, page size used); BuildError with a plain reason when even the
    smallest page is refused (the pages read so far stay stored for the next run)."""
    sub = size // 2
    while sub >= PAGE_MIN:
        ctx.log("  page at feature {:,} refused (HTTP 400) - trying {} features per page after "
                "{:.0f} s".format(offset, sub, PAGE_400_PAUSE_S))
        _pause(PAGE_400_PAUSE_S)
        try:
            d = http_json(url.rstrip("/") + "/query", dict(params, resultRecordCount=sub),
                          post=True, retries=2, what="page")
            return d, sub
        except BuildCancelled:
            raise
        except BuildError as e:
            if getattr(e, "http_code", None) != 400:
                raise
        sub //= 2
    raise BuildError(
        "the service refused the page at feature {:,} with HTTP 400 Bad Request, also with "
        "smaller pages (down to {}){}; {:,} features read so far are kept and the next run "
        "continues from there - the service is probably down or changed its query rules, run "
        "the build again later ({})".format(
            offset, PAGE_MIN, " - its object-id list failed too ({})".format(why) if why else "",
            ctx.writer.count, err))


def _feat_oid(feat, oid):
    """The object id of one ArcGIS feature, or None."""
    if not oid or not isinstance(feat, dict):
        return None
    props = feat.get("properties") or feat.get("attributes") or {}
    if oid in props:
        return props[oid]
    low = oid.lower()
    for k, v in props.items():
        if str(k).lower() == low:
            return v
    return None


def _fetch_arcgis_pages(ctx, url, bbox, oid, mrc, out_fields, precision, uid, edit=None,
                        why="", transform=None):
    transform = transform or (lambda feats: feats)
    offset, page = 0, 0
    size = max(1, min(2000, mrc))
    # BP.1: pages are offsets - kept pages are only valid while the service holds
    # the same features. Its count (+ last object id / edit date) is stored with
    # the pages; a change on resume discards them, an unknown state = PARTIAL.
    akey = "page:{}:anchor".format(size)
    now = _page_anchor(url, bbox, oid, edit)
    resume_note = ""
    # v2.8.0: a page is a chunk too (key = offset and size; payload = how many
    # features it returned and whether more follow)
    kept = ctx.writer.chunks()
    stale = [k for k in kept if not k.startswith("page:{}:".format(size))]
    if stale:
        ctx.writer.drop_chunks(stale)
        kept = ctx.writer.chunks()
    pages = [k for k in kept if k != akey]
    if pages:
        old = _unpack_json(kept[akey]) if kept.get(akey) else None
        if now is None or not isinstance(old, dict):
            resume_note = ("kept pages could not be checked against the service (feature "
                           "count {}) - features may be missing or doubled; rebuild with "
                           "--refresh".format("not answered" if now is None else
                                              "not recorded by the earlier run"))
            ctx.log("  WARNING: " + resume_note)
            ctx.status = STATUS_PARTIAL
        elif any(old.get(k) != now.get(k) for k in now if k in old):
            ctx.log("  the service changed since the pages were stored ({} -> {}) - "
                    "starting the pages over".format(old, now))
            ctx.writer.restart_stage()
            kept, pages = {}, []
    if not pages and now is not None:
        ctx.writer.add([], uid, chunk=akey, payload=_pack_json(now))
    if pages:
        ctx.log("  resuming: {} page(s) already stored".format(len(pages)))
    prev_last = None
    while True:
        key = "page:{}:{}".format(size, offset)
        meta = _unpack_json(kept[key]) if kept.get(key) else None
        if isinstance(meta, dict) and isinstance(meta.get("n"), int):
            nfe, exceeded = meta["n"], bool(meta.get("exceeded"))
            if oid and prev_last is not None and meta.get("first_oid") is not None \
                    and meta["first_oid"] <= prev_last:
                ctx.log("  stored page order no longer holds ({} then {}); starting over"
                        .format(prev_last, meta["first_oid"]))
                ctx.writer.restart_stage()
                kept, pages, offset, page, prev_last = {}, [], 0, 0, None
                continue
            if meta.get("last_oid") is not None:
                prev_last = meta["last_oid"]
            page += 1
            ctx.sub(min(95.0, page), "{:,} features".format(ctx.writer.count))
            if not nfe or (nfe < size and not exceeded):
                return resume_note
            offset += nfe
            continue
        params = dict(_envelope(bbox), where="1=1", outFields=out_fields, outSR="4326",
                      f="geojson", resultOffset=offset, resultRecordCount=size)
        if oid:
            params["orderByFields"] = "{} ASC".format(oid)
        if precision is not None:
            params["geometryPrecision"] = str(precision)
        got_size = size
        try:
            d = http_json(url.rstrip("/") + "/query", params, post=True, what="page")
        except BuildCancelled:
            raise
        except BuildError as e:
            if getattr(e, "http_code", None) != 400:
                raise
            d, got_size = _page_400(ctx, url, params, size, offset, e, why)
        feats = d.get("features", []) if isinstance(d, dict) else []
        exceeded = bool(d.get("exceededTransferLimit") or
                        (d.get("properties") or {}).get("exceededTransferLimit"))
        if got_size < size and len(feats) >= got_size:
            exceeded = True                 # a smaller page came back full: more follow
        oids = [_feat_oid(f, oid) for f in feats]
        oids = [v for v in oids if v is not None]
        payload = {"n": len(feats), "exceeded": exceeded}
        if oids:
            payload["first_oid"], payload["last_oid"] = oids[0], oids[-1]
        if oid and prev_last is not None and oids and oids[0] <= prev_last:
            ctx.log("  page order changed (first oid {} is not after {}); starting the pages over"
                    .format(oids[0], prev_last))
            ctx.writer.restart_stage()
            kept, pages, offset, page, prev_last = {}, [], 0, 0, None
            continue
        added = ctx.writer.add(transform(feats), uid, chunk=key, payload=_pack_json(payload))
        page += 1
        ctx.sub(min(95.0, page), "{:,} features".format(ctx.writer.count))
        if not feats or (len(feats) < size and not exceeded):
            return resume_note
        if added == 0:
            return "the service repeats the same page (no paging) - {:,} kept".format(
                ctx.writer.count)
        if oids:
            prev_last = oids[-1]
        offset += len(feats)


# -------------------------------------------------------------------- NSI --
def _tiles(b, deg):
    x0, y0, x1, y1 = b
    nx = max(1, int(math.ceil((x1 - x0) / deg - 1e-9)))
    ny = max(1, int(math.ceil((y1 - y0) / deg - 1e-9)))
    dx, dy = (x1 - x0) / nx, (y1 - y0) / ny
    return [(x0 + i * dx, y0 + j * dy, x0 + (i + 1) * dx, y0 + (j + 1) * dy)
            for j in range(ny) for i in range(nx)]


def _nsi_tile(tile, depth=0):
    x0, y0, x1, y1 = tile
    ring = [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]
    bbox = ",".join("{:.6f},{:.6f}".format(x, y) for x, y in ring)
    try:
        d = http_json(C.NSI_API_URL, {"bbox": bbox, "fmt": "fc"}, what="NSI tile")
        return d.get("features", []) if isinstance(d, dict) else []
    except BuildCancelled:
        raise
    except BuildError:
        if depth >= 2:
            raise
        out = []
        for q in _split4(tile):
            out += _nsi_tile(q, depth + 1)
        return out


def fetch_nsi(ctx, bbox):
    tiles = _tiles(bbox, _nsi_tile_deg())
    ctx.log("  {} tiles of {} degree".format(len(tiles), _nsi_tile_deg()))
    have, keys = _resume_tiles(ctx, tiles)
    failed = []
    done = [len(have)]

    def uid(f):
        return (f.get("properties") or {}).get("fd_id")

    def got(args, res):
        if isinstance(res, Exception):
            failed.append((args[0], str(res)))
        else:
            ctx.writer.add(res, uid, chunk=_tile_key(args[0]))
        done[0] += 1
        ctx.sub(100.0 * done[0] / len(tiles), "{} of {} tiles, {:,} structures".format(
            done[0], len(tiles), ctx.writer.count))
    _pool(ctx, ctx.workers, [(_nsi_tile, (t,)) for t, k in zip(tiles, keys)
                             if k not in have], got)
    if failed:
        if len(failed) > max(2, len(tiles) // 20):
            raise BuildError("{} of {} NSI tiles failed, e.g. {}".format(
                len(failed), len(tiles), failed[0][1]))
        note = "{} tile(s) could not be read: {}".format(len(failed), "; ".join(
            "{:.2f},{:.2f}".format(t[0], t[1]) for t, _e in failed))
        ctx.log("  WARNING: " + note)
        # v2.6.2: the plugin treats a study area touching these as not covered
        ctx.gaps = [tuple(t) for t, _e in failed]
        return note
    return ""


# -------------------------------------------------------------- Overpass --
def _overpass(query):
    d = http_json(C.OVERPASS_URL, {"data": query}, post=True, what="Overpass")
    remark = d.get("remark") if isinstance(d, dict) else None
    if remark and any(s in str(remark).lower() for s in
                      ("error", "timed out", "timeout", "out of memory", "aborted")):
        raise BuildError("Overpass: {}".format(remark))
    return d


def _osm_tile(make_query, parse, tile, depth=0):
    try:
        return parse(_overpass(O.with_timeout(make_query(tile), OVERPASS_TIMEOUT_S)))
    except BuildCancelled:
        raise
    except BuildError:
        if depth >= 2:
            raise
        out = []
        for q in _split4(tile):
            out += _osm_tile(make_query, parse, q, depth + 1)
        return out


def fetch_osm(ctx, bbox, make_query, parse):
    tiles = _tiles(bbox, OVERPASS_TILE_DEG)
    have, keys = _resume_tiles(ctx, tiles)
    done = [len(have)]
    errors = []

    def uid(f):
        return (f.get("properties") or {}).get("osm_id")

    def got(args, res):
        if isinstance(res, Exception):
            errors.append(res)
        else:
            ctx.writer.add(res, uid, chunk=_tile_key(args[2]))
        done[0] += 1
        ctx.sub(100.0 * done[0] / len(tiles), "{} of {} areas, {:,} features".format(
            done[0], len(tiles), ctx.writer.count))
    _pool(ctx, min(ctx.workers, C.OVERPASS_WORKERS),
          [(_osm_tile, (make_query, parse, t)) for t, k in zip(tiles, keys)
           if k not in have], got)
    if errors:
        # an area missing would silently drop features: the data set fails
        raise BuildError("{} of {} areas failed: {}".format(len(errors), len(tiles), errors[0]))
    return ""


# ------------------------------------------------------------- data sets --


def pack_layers():
    """Which layer list this plugin's pack holds: "nd" (the ND Dam Suite: 3DHP hydro, layer
    files, land cover; a folder pack) or "dwr" (the DamSafety suite: NHD hydro, a one-file zip).
    constants.PACK_LAYERS of the plugin that bound this engine; "dwr" when it has none.
    Packbuild 1.0 (suite 1.18.6): one engine for both suites. Packbuild 1.1: both lists hold
    the same barrier and ND DEQ layers (shared_datasets())."""
    return getattr(C, "PACK_LAYERS", "dwr") or "dwr"


def datasets(dwr_folder=None, layers=None):
    """[(name, label, group, kind, spec)] - name = the plugin's download
    name, so the plugin finds each data set under the name it asks for.
    layers: "nd" / "dwr" (default: pack_layers()). 2.18.66: dwr_folder (a folder of the ND
    DWR GeoPackages): the DWR_* data sets of group "dwr" (kind "local_gpkg") are added for the
    files found there."""
    layers = layers or pack_layers()
    d = _datasets_nd() if layers == "nd" else _datasets_dwr()
    if dwr_folder:
        d += dwr_datasets(dwr_folder)
    return d


def _datasets_dwr():
    """The DamSafety suite's layer list (see datasets())."""
    nhd_fields = "gnis_name,gnis_id,ftype,fcode,reachcode,lengthkm"
    d = [
        ("NSI_structures", "USACE National Structure Inventory", "nsi", "nsi", {}),
        ("NDGISHUB_address_points", "ND GIS Hub site / structure address points", "address",
         "arcgis", {"url": C.ND_ADDRESS_POINTS_URL}),
        ("USA_Structures", "FEMA USA Structures outlines", "usa", "arcgis",
         {"url": C.USA_STRUCTURES_URL}),
        ("NID_dams", "National Inventory of Dams", "nid", "arcgis",
         {"urls": [C.NID_URL, C.NID_MIRROR_URL]}),
        ("NARN_rail_lines", "FRA/BTS rail network", "rail", "arcgis", {"url": C.NARN_URL}),
        ("FRA_grade_crossings", "FRA grade crossings", "rail", "arcgis",
         {"url": C.CROSSINGS_URL}),
        ("ND_roads_NG911", "ND GIS Hub NG9-1-1 road centerlines", "roads", "arcgis",
         {"url": C.ND_ROADS_URL}),
    ]
    hpms = []
    for url in C.HPMS_ND_URLS:
        year = "".join(ch for ch in url.split("HPMS_FULL_ND_")[-1][:4] if ch.isdigit())
        hpms.append(("HPMS_ND_{}".format(year), url))
    d.append(("HPMS_ND", "FHWA HPMS North Dakota (newest year that answers)", "traffic",
              "first_of", {"choices": hpms}))
    if C.NDDOT_AADT_URL:
        d.append(("NDDOT_traffic_counts", "NDDOT traffic counts", "traffic", "arcgis",
                  {"url": "{}/{}".format(C.NDDOT_AADT_URL.rstrip("/"),
                                         C.NDDOT_AADT_LAYERS.get("aadt", 0))}))
    d.append(("ND_county_roads", "ND GIS Hub county roads (AADT)", "traffic", "arcgis",
              {"url": C.ND_COUNTY_ROADS_URL}))
    for key, label, url, _cat in C.lifeline_downloads():
        d.append(("lifeline_" + key, label, "lifelines", "arcgis", {"url": url}))
    d += [
        ("NBI_bridges", "National Bridge Inventory", "bridges", "arcgis", {"url": C.NBI_URL}),
        ("NHD_flowlines", "USGS NHD flowlines (name and type only)", "nhd", "arcgis",
         {"url": C.NHD_FLOWLINE_URL, "fields": nhd_fields, "precision": 6}),
        ("NHD_waterbodies", "USGS NHD waterbodies (large scale)", "waterbodies", "arcgis",
         {"url": C.NHD_WATERBODY_URL,
          "fields": "PERMANENT_IDENTIFIER,GNIS_ID,GNIS_NAME,AREASQKM,ELEVATION,REACHCODE,FTYPE,FCODE",
          "precision": 6}),
        ("OSM_lifelines", "OpenStreetMap lifeline facilities", "osm", "osm",
         {"query": O.overpass_query, "parse": O.overpass_to_features}),
        ("OSM_crossings", "OpenStreetMap culverts / fords / rail bridges", "osm", "osm",
         {"query": O.crossings_query, "parse": O.crossing_features}),
        ("OSM_campgrounds", "OpenStreetMap campgrounds / RV parks", "osm", "osm",
         {"query": O.camps_query, "parse": O.camp_features}),
        ("OSM_trailer_parks", "OpenStreetMap mobile-home parks", "osm", "osm",
         {"query": O.trailer_parks_query, "parse": O.trailer_park_features}),
        ("OSM_places", "OpenStreetMap cities / towns / villages", "osm", "osm",
         {"query": O.places_query, "parse": O.place_features}),
    ]
    d += shared_datasets()
    return d


def _datasets_nd():
    """The ND Dam Suite's layer list (see datasets())."""
    d = [
        ("NSI_structures", "USACE National Structure Inventory", "nsi", "nsi", {}),
        ("NDGISHUB_address_points", "ND GIS Hub site / structure address points", "address",
         "arcgis", {"url": C.ND_ADDRESS_POINTS_URL}),
        ("USA_Structures", "FEMA USA Structures outlines", "usa", "arcgis",
         {"url": C.USA_STRUCTURES_URL}),
        ("NID_dams", "National Inventory of Dams", "nid", "arcgis",
         {"urls": [C.NID_URL, C.NID_MIRROR_URL]}),
        ("NARN_rail_lines", "FRA/BTS rail network", "rail", "arcgis", {"url": C.NARN_URL}),
        ("FRA_grade_crossings", "FRA grade crossings", "rail", "arcgis",
         {"url": C.CROSSINGS_URL}),
        ("ND_roads_NG911", "ND GIS Hub NG9-1-1 road centerlines", "roads", "arcgis",
         {"url": C.ND_ROADS_URL}),
    ]
    hpms = []
    for url in C.HPMS_ND_URLS:
        year = "".join(ch for ch in url.split("HPMS_FULL_ND_")[-1][:4] if ch.isdigit())
        hpms.append(("HPMS_ND_{}".format(year), url))
    d.append(("HPMS_ND", "FHWA HPMS North Dakota (newest year that answers)", "traffic",
              "first_of", {"choices": hpms}))
    if C.NDDOT_AADT_URL:
        d.append(("NDDOT_traffic_counts", "NDDOT traffic counts", "traffic", "arcgis",
                  {"url": "{}/{}".format(C.NDDOT_AADT_URL.rstrip("/"),
                                         C.NDDOT_AADT_LAYERS.get("aadt", 0))}))
    d.append(("ND_county_roads", "ND GIS Hub county roads (AADT)", "traffic", "arcgis",
              {"url": C.ND_COUNTY_ROADS_URL}))
    for key, label, url, _cat in C.lifeline_downloads():
        d.append(("lifeline_" + key, label, "lifelines", "arcgis", {"url": url}))
    d += [
        ("NBI_bridges", "National Bridge Inventory", "bridges", "arcgis", {"url": C.NBI_URL}),
        ("3DHP_flowlines", "USGS 3DHP flowlines (3D Hydrography Program)", "hydro", "arcgis",
         _hydro_spec(C.NHD_FLOWLINE_URL, True)),
        ("3DHP_waterbodies", "USGS 3DHP waterbodies (3D Hydrography Program)", "hydro", "arcgis",
         _hydro_spec(C.NHD_WATERBODY_URL, False)),
        ("OSM_lifelines", "OpenStreetMap lifeline facilities", "osm", "osm",
         {"query": O.overpass_query, "parse": O.overpass_to_features}),
        ("OSM_crossings", "OpenStreetMap culverts / fords / rail bridges", "osm", "osm",
         {"query": O.crossings_query, "parse": O.crossing_features}),
        ("OSM_campgrounds", "OpenStreetMap campgrounds / RV parks", "osm", "osm",
         {"query": O.camps_query, "parse": O.camp_features}),
        ("OSM_trailer_parks", "OpenStreetMap mobile-home parks", "osm", "osm",
         {"query": O.trailer_parks_query, "parse": O.trailer_park_features}),
        ("OSM_places", "OpenStreetMap cities / towns / villages", "osm", "osm",
         {"query": O.places_query, "parse": O.place_features}),
    ]
    d += shared_datasets()
    d += file_datasets()
    d += suite_datasets()
    return d


# ------------------------------------------- the barrier and ND DEQ layers (one list) --
# packbuild 1.1: the same layers, names and sources in both suites' packs. DamSafety_Data's
# registry() and the ND list above both take them from shared_datasets().
USGS_STREAM_CROSSINGS_URL = ("https://services.arcgis.com/v01gqwM5QqNysAAi/ArcGIS/rest/services/"
                             "stream_crossings/FeatureServer/0")
# OBJECTID is kept as the row key: some crossings appear more than once under one
# stream_crossing_id (one row per TIGER road line or structure type), all of them are kept
USGS_CROSSING_FIELDS = ("OBJECTID,stream_crossing_id,nhdhr_permanent_identifier,"
                        "nhdhr_gnis_stream_name,tiger2020_linearids,tiger2020_feature_names,"
                        "nhdhr_reachcode,nhdhr_fdate,tiger2020_mtfcc_feature_class,"
                        "crossing_type")
USGS_CROSSING_SOURCE = ("Wieferich, D.J., 2022, Database of Stream Crossings in the United "
                        "States: U.S. Geological Survey data release, doi:10.5066/P9YX6KTB "
                        "(TIGER 2020 roads x NHD High Resolution flowlines; bridge / culvert "
                        "type from the 2019 NBI; modelled, not field-checked)")
# ND Department of Environmental Quality layers published on the ND GIS Hub (public ArcGIS
# REST; DEQ's own ArcGIS Online services hold no facility points). DEQ does not publish
# wastewater / NDPDES facilities, public water system plants or intakes as GIS layers.
NDDEQ_HUB = "https://ndgishub.nd.gov/arcgis/rest/services/All_Locations/MapServer/"
NDDEQ = (
    ("NDDEQ_landfills", "ND DEQ permitted landfills (Division of Waste Management)", 12,
     "Selected landfills permitted in North Dakota; WasteType = the primary waste accepted"),
    ("NDDEQ_source_water_protection_community", "ND DEQ source water protection areas - "
     "community public water systems", 16, "Drinking-water source protection areas of "
     "community public water systems (PWS_NAME, PWS_TYPE, PWS_SOURCE); intakes not published"),
    ("NDDEQ_source_water_protection_noncommunity", "ND DEQ source water protection areas - "
     "non-community public water systems", 17, "Drinking-water source protection areas of "
     "non-community public water systems; intakes not published"),
)


def shared_datasets():
    """[(name, label, group, kind, spec)] of the layers both suites' packs hold the same way:
    the Aquatic Barrier Inventory (ABI_*, kind "abi"), the USGS stream crossings and the ND DEQ
    layers. spec["source"] / ["note"] / ["used_by"] describe the layer (the ND pack's
    LAYERS.txt, DamSafety_Data's manifest)."""
    from . import abi as A
    d = []
    for name, label, spec in A.ABI:
        d.append((name, label, "barriers", "abi", dict(
            spec, source=A.source_of(spec), note=A.ABI_NOTE,
            used_by="reference (fish passage / dam inventory cross-check)" if spec["kind"] ==
            "dams" else "reference (culverts and bridges on streams)")))
    d.append(("USGS_stream_crossings", "USGS road / stream crossings (Database of Stream "
              "Crossings in the United States)", "barriers", "arcgis",
              {"url": USGS_STREAM_CROSSINGS_URL, "fields": USGS_CROSSING_FIELDS, "precision": 6,
               "source": USGS_CROSSING_SOURCE,
               "used_by": "reference (modelled road-stream crossings; the base of the "
                          "inventory's unsurveyed crossings)"}))
    for name, label, lid, note in NDDEQ:
        d.append((name, label, "nddeq", "arcgis", {
            "url": NDDEQ_HUB + str(lid), "note": note,
            "source": "ND Department of Environmental Quality, via the ND GIS Hub "
                      "(All_Locations layer {})".format(lid)}))
    return d


ZIP_MAX_AGE_S = 7 * 86400                    # a national download is used again for a week
ABI_BATCH = 2000                             # features written per batch


def _download_resume(url, dest, max_age=ZIP_MAX_AGE_S, refresh=False, beat=None):
    """Download url to dest (streaming, continued with an HTTP Range request after a broken
    connection); a file younger than max_age is used as it is. Returns (path, downloaded_now)."""
    if not refresh and os.path.isfile(dest) and time.time() - os.path.getmtime(dest) < max_age:
        return dest, False
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    part = dest + ".part"
    if refresh and os.path.exists(part):
        os.remove(part)
    for attempt in range(6):
        have = os.path.getsize(part) if os.path.exists(part) else 0
        headers = {"User-Agent": _ua()}
        if have:
            headers["Range"] = "bytes={}-".format(have)
        try:
            with urlopen(Request(url, headers=headers), timeout=TIMEOUT_S) as r:
                status = getattr(r, "status", 200)
                mode = "ab" if have and status == 206 else "wb"
                total = r.headers.get("Content-Length")
                total = int(total) + (have if mode == "ab" else 0) if total else None
                got = have if mode == "ab" else 0
                with open(part, mode) as f:
                    for block in iter(lambda: r.read(1 << 20), b""):
                        _check_cancel()
                        f.write(block)
                        got += len(block)
                        if beat:
                            beat(got, total)
            if total and got < total:
                raise BuildError("download cut off at {:,} of {:,} bytes".format(got, total))
            os.replace(part, dest)
            return dest, True
        except BuildCancelled:
            raise
        except HTTPError as e:
            if e.code == 416 and have:              # the part is whole already
                os.replace(part, dest)
                return dest, True
            if attempt == 5:
                raise
        except (URLError, TimeoutError, OSError, BuildError):
            if attempt == 5:
                raise
        _sleep_plain(min(60, 5 * 2 ** attempt))
    raise BuildError("download failed: " + url)


def fetch_abi(ctx, bbox, spec):
    """Packbuild 1.1: one Aquatic Barrier Inventory layer (damsuite.abi): the public API's state
    CSV, or the national road-crossings download (~600 MB zip, kept in <work>/downloads/abi/ for
    a week, continued after a broken connection; --refresh downloads it again), its North Dakota
    unsurveyed rows. Every column kept, network and barrier_status added."""
    from . import abi as A
    dest = os.path.join(os.path.dirname(os.path.abspath(ctx.writer.path)), "downloads", "abi")

    def beat(got, total):
        if total:
            ctx.sub(60.0 * got / total, "downloading {:,} of {:,} MB".format(
                got >> 20, total >> 20))
        else:
            ctx.sub(30.0, "downloading {:,} MB".format(got >> 20))

    def download(url, path, refresh, log, max_age=86400):
        got = _download_resume(url, path, max_age=max_age, refresh=refresh, beat=beat)
        if log:
            log("  {}: {} ({:,} KB)".format(url.split("?")[0], "downloaded now" if got[1] else
                                            "kept from an earlier run",
                                            os.path.getsize(got[0]) >> 10))
        return got
    head, rows, prov = A.abi_rows(spec, dest, download, refresh=getattr(ctx, "refresh", False),
                                  log=ctx.log, errors=_NET_ERRORS)
    _check_cancel()
    ctx.sub(60.0, "reading {:,} rows".format(len(rows)))
    feats = A.abi_features(head, rows, bbox)
    n = 0
    for i in range(0, len(feats), ABI_BATCH):
        _check_cancel()
        n += ctx.writer.add(feats[i:i + ABI_BATCH], A.feature_uid)
        ctx.sub(60.0 + 39.0 * min(len(feats), i + ABI_BATCH) / max(1, len(feats)),
                "{:,} features".format(min(len(feats), i + ABI_BATCH)))
    return "{} (data version {})".format(prov.get("filter"), prov.get("data_version") or "?")


def _hydro_spec(url, flow):
    """The 3DHP layer's spec; a data-source file that points the address at the older NHD service
    gets that service's own fields (and no transform)."""
    if H3.is_3dhp_url(url):
        return {"url": url, "fields": H3.FLOW_FIELDS if flow else H3.WB_FIELDS, "precision": 6,
                "tile_deg": 0.25,
                "transform": H3.normalise_flowlines if flow else H3.normalise_waterbodies,
                "source": "USGS 3D Hydrography Program (3DHP_all MapServer, layer {}); "
                          "NHD-style gnis_name / gnis_id / ftype / fcode added to the 3DHP "
                          "properties".format(H3.layer_of_url(url)),
                "used_by": "Hazard (travel time), Breach Runner (culverts), Screening (pool "
                           "area)"}
    return {"url": url, "precision": 6, "fields": "gnis_name,gnis_id,ftype,fcode,reachcode,"
            "lengthkm" if flow else "gnis_name,gnis_id,ftype,fcode,areasqkm"}


def file_datasets():
    """1.19.0: the layers that come from files (DWR exports, HIFLD downloads) and the NLCD raster.
    kind "file": packfiles scans the suite data folder's dwr/ and hifld/ (and --files); the DWR
    dams fall back to the DWR service when no file is found. kind "raster": the MRLC web
    coverage service, written as a GeoPackage raster (needs GDAL)."""
    out = []
    for name, label, _src, _g, _b in PF.KNOWN:
        if name in PF.OSM_NAMES:         # listed in datasets() as Overpass downloads; a file wins
            continue
        spec = {}
        if name == "DWR_dams":
            spec = {"fallback": {"url": C.DWR_DAMS_URL, "precision": 6,
                                 "source": "ND DWR dams inventory, public service (95 of the "
                                           "export's 109 fields); a DWR export file in dwr/ "
                                           "replaces it",
                                 "used_by": "Screening, Breach Runner"}}
        out.append((name, label, "dwr" if name.startswith("DWR") else "hifld", "file", spec))
    out.append((NLCD_NAME, "NLCD 2021 land cover, North Dakota, 30 m (EPSG:5070)", "landcover",
                "raster", {"service": "mrlc_nlcd2021_wcs",
                           "source": "USGS / MRLC National Land Cover Database 2021 (MRLC WCS)",
                           "used_by": "Screening, Breach Runner (Manning's n)"}))
    return out


# 2.17.0: data sets the suite's dam data reads (damsuite.damdata.PACK_SETS) from the servers
# chosen in Suite data and servers: counties always (the built-in server), the DWR dams and dam
# lines and FEMA flood zones only when a server was chosen there (the built-in DWR choice is the
# HSIP copy, not DWR's inventory; statewide flood zones are large)
SUITE_SETS = (("counties", "ND_counties", "County boundaries", "reference", True),
              ("dwr_dams", "DWR_dams", "ND DWR dams inventory", "dwr", False),
              ("dwr_dam_lines", "DWR_dam_lines", "ND DWR dam lines", "dwr", False),
              ("flood_zones", "FEMA_flood_zones", "FEMA flood hazard zones", "reference", False))


def suite_datasets(catalog=None):
    try:
        from . import services as SV
        cat = catalog if catalog is not None else SV.load()
    except Exception:                                # noqa - no suite list: nothing extra
        return []
    out = []
    for role, name, label, group, always in SUITE_SETS:
        if not always and not cat.choice.get(role):
            continue
        s = cat.chosen(role)
        if s is None or s.get("kind") not in ("arcgis_feature", "arcgis_map") or \
                not SV.data_capable(s, role):
            continue
        try:
            url = SV.layer_url(s)
        except SV.ServiceError:
            continue
        out.append((name, "{} ({})".format(label, s.get("name") or url), group, "arcgis",
                    {"url": url}))
    return out


def dwr_datasets(folder):
    """2.18.66: the DWR_* data sets of the GeoPackages in `folder` (the suite folder's layer
    rules, dwr_files.find_layers). A data set with no file is left out (and named)."""
    try:
        found = _df().find_layers(os.path.abspath(folder))
    except _df().DwrFileError as e:
        raise BuildError(str(e))
    out = []
    for name, slot, label, what in _df().DATASETS:
        if name in found:
            path, layer = found[name]
            out.append((name, label, _df().GROUP, "local_gpkg",
                        {"path": path, "layer": layer, "slot": slot, "what": what}))
    if not out:
        raise BuildError("no ND DWR GeoPackage found in {} (DWR_Dams.gpkg, DWR_Dam_Lines.gpkg, "
                         "DWR_Unknown_Structures.gpkg, DWR_Dugouts.gpkg, "
                         "DWR_Dugouts_Polygons.gpkg)".format(folder))
    return out


def fetch_local_gpkg(ctx, spec):
    """2.18.66: one layer of a local GeoPackage into the pack: every attribute kept, the
    geometry reprojected to lon / lat (dwr_files). Returns the manifest note: the source file,
    its layer, CRS and file date."""
    path, layer = spec["path"], spec["layer"]
    try:
        feats, info = _df().read_layer(path, layer)
    except _df().DwrFileError as e:
        raise BuildError(str(e))
    ctx.sub(50, "{:,} features read".format(len(feats)))
    ctx.writer.add(feats, _df().uid_of)
    # kept as they are, but said: a feature wholly outside North Dakota (+ the pad) is most
    # likely a bad geometry in the source (DWR dugout structure 2163, point and polygon)
    x0, y0, x1, y1 = (ND_BBOX[0] - DEFAULT_PAD_DEG, ND_BBOX[1] - DEFAULT_PAD_DEG,
                      ND_BBOX[2] + DEFAULT_PAD_DEG, ND_BBOX[3] + DEFAULT_PAD_DEG)
    out = 0
    for f in feats:
        b = _df().bbox_of(f.get("geometry"))
        if b and (b[2] < x0 or b[0] > x1 or b[3] < y0 or b[1] > y1):
            out += 1
    extra = []
    if out:
        extra.append("{:,} wholly outside North Dakota (kept)".format(out))
    # 1.3: the file's own date (GeoPackage last change), not the day it was copied here
    day, how = _df().source_date(path, layer)
    ctx.source_date = (day, how)
    return "from {} layer {} (EPSG:{}{}, file dated {} ({}), {:,} rows{})".format(
        os.path.basename(path), layer, info["epsg"],
        ", unit {:g} m".format(info["unit_m"]) if info["unit_m"] != 1.0 else "",
        day, how, info["rows"], "; " + ", ".join(extra) if extra else "")


class _Ctx(object):
    def __init__(self, writer, workers, log, sub, beat=None, refresh=False):
        self.writer, self.workers, self.log, self.sub = writer, workers, log, sub
        self.beat = beat                     # v2.8.0: beat(text) - progress while waiting
        self.refresh = refresh               # v2.8.0: no chunk resume
        self.status = "complete"             # v2.6.2: or partial
        self.gaps = []                       # boxes that could not be read


_GROUP_ALIASES = {"nhd": "hydro", "3dhp": "hydro", "nlcd": "landcover", "sarp": "barriers",
                  "abi": "barriers", "deq": "nddeq",
                  "NHD_flowlines": "3DHP_flowlines", "NHD_waterbodies": "3DHP_waterbodies"}
# packbuild 1.1: --only SARP_dams etc. (the ND names before the shared list) pick the ABI_* layers
_GROUP_ALIASES.update((k, v) for k, v in H3.BARRIER_ALIASES.items() if k.startswith("SARP_"))


def _pick(names_or_groups, table):
    want = set(_GROUP_ALIASES.get(x.strip(), x.strip()) if pack_layers() == "nd" else x.strip()
               for x in (names_or_groups or "").split(",") if x.strip())
    if not want:
        return None
    known = set(t[0] for t in table) | set(t[2] for t in table)
    bad = want - known
    if bad:
        raise BuildError("unknown data set(s): {} (see --list{})".format(
            ", ".join(sorted(bad)), "; the dwr group needs --dwr-folder PATH" if (
                "dwr" in bad or any(b.startswith("DWR_") for b in bad)) else ""))
    return want


DWR_DOWNLOAD_URL = "https://mapservice.dwr.nd.gov/php/downloadShape.php"
DWR_MAPFILE = "/Volumes/Data/WebServer/newswcprivate/mapfiles/swc.map"
# the web map's full extent (EPSG:2266, ND South State Plane, international feet)
DWR_FULL_EXTENT = (1026879.6641881, 54774.288373765, 2999091.3458676, 1331032.7378794)
DWR_FORMATS = {"shp": ".shp", "spat": ".sqlite"}
DWR_DOWNLOADS = (     # (data set, MapService layer index (for reference), qlay = layer name)
    ("DWR_dam_lines", 253, "Damsline"),
    ("DWR_dams", 254, "Dams"),
    ("DWR_dugout_polygons", 276, "DugoutsPoly"),
    ("DWR_dugouts", 277, "Dugouts"),
)


def dwr_extent(bbox=None):
    """mapext of a DWR download: a lon / lat bbox (west, south, east, north) as the EPSG:2266
    box around it (feet, '+'-separated, the way the web map sends it); None -> the full map."""
    if bbox is None:
        box = DWR_FULL_EXTENT
    else:
        proj, unit = _df()._KNOWN[2266]
        w, s, e, n = (float(v) for v in bbox)
        pts = [proj.forward(x, y) for x in (w, e) for y in (s, n)]
        pts += [proj.forward((w + e) / 2.0, y) for y in (s, n)]    # the arc of the parallels
        xs = [p[0] / unit for p in pts]
        ys = [p[1] / unit for p in pts]
        box = (min(xs), min(ys), max(xs), max(ys))
    return "+".join("{:.3f}".format(v) for v in box)


def dwr_request(qlay, bbox=None, fmt="shp"):
    """The form fields of one DWR MapService download (see DWR_DOWNLOAD_URL)."""
    if fmt not in DWR_FORMATS:
        raise BuildError("DWR download format must be one of {}".format(", ".join(DWR_FORMATS)))
    return {"whichextent": "all" if bbox is None else "partial", "srid": "4269",
            "downloadformat": fmt, "qlay": qlay, "mapext": dwr_extent(bbox),
            "map": DWR_MAPFILE}


def download_dwr_shapefiles(dest_folder, log=None, bbox=None, fmt="shp", only=None):
    """Download the four ND DWR layers (dams, dam lines, dugouts, dugout polygons) from the
    DWR MapService and extract each zip into dest_folder/<data set>/.

    bbox (west, south, east, north, lon / lat) downloads only that area (the form's "Data
    within current view"); None -> the full data set. fmt "shp" (shapefile: 10-character
    field names) or "spat" (SpatiaLite: full field names). Coordinates NAD83 lon / lat
    (srid 4269). only: data set names or qlay names to fetch (None -> all four).
    Returns the list of extracted folders; a layer that fails is logged and skipped. An
    answer that is not a zip (the old request got an empty one) is never saved as a .zip."""
    import urllib.request
    import urllib.parse
    log = log or (lambda m: None)
    os.makedirs(dest_folder, exist_ok=True)
    out = []
    for name, _index, qlay in DWR_DOWNLOADS:
        if only and name not in only and qlay not in only:
            continue
        data = urllib.parse.urlencode(dwr_request(qlay, bbox, fmt)).encode()
        req = urllib.request.Request(DWR_DOWNLOAD_URL, data=data,
                                     headers={"User-Agent": _ua()})
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:
                raw = r.read()
        except Exception as e:
            log("  {} failed: {}".format(qlay, e))
            continue
        if not raw.startswith(b"PK"):
            log("  {}: the DWR MapService sent no file ({} bytes)".format(qlay, len(raw)))
            continue
        zpath = os.path.join(dest_folder, "{}.zip".format(name))
        with open(zpath + ".part", "wb") as f:
            f.write(raw)
        os.replace(zpath + ".part", zpath)
        sub = os.path.join(dest_folder, name)
        os.makedirs(sub, exist_ok=True)
        try:
            with zipfile.ZipFile(zpath) as zf:
                zf.extractall(sub)
                names = zf.namelist()
        except zipfile.BadZipFile:
            log("  {} is not a zip ({} bytes)".format(qlay, len(raw)))
            continue
        if not any(n.lower().endswith(DWR_FORMATS[fmt]) for n in names):
            log("  {}: the zip holds no {} file ({})".format(qlay, DWR_FORMATS[fmt],
                                                             ", ".join(names)))
            continue
        out.append(sub)
        log("  {} -> {} ({:,} bytes)".format(qlay, sub, len(raw)))
    return out


def build(out_zip, pad=DEFAULT_PAD_DEG, only=None, skip=None, workers=None, refresh=False,
          sources_file=None, progress=None, log=None, files=None, box=None, dwr_folder=None):
    """Build (or resume / update) the pack and write out_zip. progress(pct,
    msg) and log(msg) are optional callbacks; an exception raised by
    progress (a cancel) stops the build - the finished data sets are kept
    for the next run. Returns the manifest. box: (xmin, ymin, xmax, ymax) lon / lat of another
    area than North Dakota. files: extra folders searched for the DWR / HIFLD
    layer files (the suite data folder's dwr/ and hifld/ are always searched; folder packs
    only). 2.18.66: dwr_folder adds the ND DWR GeoPackages of that folder (group "dwr"; read
    again on every run - they are local). The DamSafety layer list (pack_layers() "dwr")
    always writes the one-file zip (".zip" is added to out_zip)."""
    log = log or print
    progress = progress or (lambda p, m: None)
    _CANCEL.clear()
    # v2.6.2: inside QGIS the plugin has applied the data-source file already;
    # applying it again from here cleared the plugin's overrides
    if sources_file and _SCRIPT[0]:
        C.apply_source_overrides(sources_file)
        if C.SOURCE_OVERRIDES:
            log("Data-source file {}: {} address(es) changed".format(
                sources_file, len(C.SOURCE_OVERRIDES)))
    table = datasets(dwr_folder)
    only_set, skip_set = _pick(only, table), _pick(skip, table) or set()
    chosen = [t for t in table if (only_set is None or t[0] in only_set or t[2] in only_set)
              and t[0] not in skip_set and t[2] not in skip_set]
    todo = [t for t in chosen if t[3] not in ("file", "raster")]
    file_todo = [t for t in chosen if t[3] == "file"]
    raster_todo = [t for t in chosen if t[3] == "raster"]
    bbox = tuple(float(v) for v in box) if box else \
        (ND_BBOX[0] - pad, ND_BBOX[1] - pad, ND_BBOX[2] + pad, ND_BBOX[3] + pad)
    out_zip = os.path.abspath(out_zip)
    if pack_layers() != "nd" and not out_zip.lower().endswith(".zip"):
        out_zip += ".zip"
    # 2.24.0: a folder pack (one GeoPackage per layer) unless the name ends in .zip
    folder_pack = not out_zip.lower().endswith(".zip")
    if (file_todo or raster_todo) and not folder_pack:
        log("The layer files and the land cover are added to a pack FOLDER only (not to a "
            ".zip): {}".format(", ".join(t[0] for t in file_todo + raster_todo)))
        file_todo, raster_todo = [], []
    left_out = {}                            # 1.19.0: what could not be put in, and why
    if folder_pack and any(t[0] in ("3DHP_flowlines", "3DHP_waterbodies") for t in todo):
        todo = _add_3dhp_bulk(out_zip, todo, bbox, files, refresh, progress, log)
    if file_todo:
        todo += _add_layer_files(out_zip, file_todo, bbox, files, refresh, left_out, progress,
                                 log)
    if folder_pack and any(t[0] in PF.OSM_NAMES for t in todo):
        todo = _add_osm_files(out_zip, todo, bbox, files, refresh, progress, log)
    work = (out_zip.rstrip("\\/") if folder_pack else os.path.splitext(out_zip)[0]) + "_work"
    os.makedirs(work, exist_ok=True)
    db = os.path.join(work, DB_NAME)
    log("Offline data pack for North Dakota - area {:.3f}, {:.3f} to {:.3f}, {:.3f} "
        "(lon / lat)".format(*bbox))
    log("Working file: {}".format(db))
    writer = PackWriter(db, bbox, created_by="build_nd_pack.py {} / plugin {}".format(
        BUILDER_VERSION, C.PLUGIN_VERSION))
    workers = max(1, int(workers or C.DOWNLOAD_WORKERS))
    failures = []
    try:
        n = len(todo)
        for i, (name, label, _group, kind, spec) in enumerate(todo):
            lo, hi = 100.0 * i / n, 100.0 * (i + 1) / n

            shown = {"p": 0.0, "m": ""}

            def sub(p, m="", lo=lo, hi=hi, label=label, shown=shown):
                shown["p"], shown["m"] = p, m
                progress(lo + (hi - lo) * max(0.0, min(100.0, p)) / 100.0,
                         "{}: {}".format(label, m) if m else label)

            def beat(text, lo=lo, hi=hi, label=label, shown=shown):
                # v2.8.0: the bar does not move, but the message shows life
                progress(lo + (hi - lo) * max(0.0, min(100.0, shown["p"])) / 100.0,
                         "{}: {}{}".format(label, text, " - " + shown["m"] if shown["m"] else ""))
            ctx = _Ctx(writer, workers, log, sub, beat, refresh)
            names = [c[0] for c in spec["choices"]] if kind == "first_of" else [name]
            # (partial, or complete with gaps: fetched again - it may be complete now;
            # a failed re-fetch keeps what there is)
            if kind != "local_gpkg" and not refresh and any(writer.done(x) for x in names):
                log("[{}/{}] {}: already in the pack (kept - --refresh fetches it "
                    "again)".format(i + 1, n, label))
                continue
            log("[{}/{}] {}".format(i + 1, n, label))
            sub(0, "starting")
            t0 = time.time()
            try:
                got = _run_one(ctx, name, label, kind, spec, bbox)
                log("  done: {:,} features in {:.0f} s".format(got, time.time() - t0))
            except (PackError, BuildCancelled):
                raise
            except _NET_ERRORS as e:
                failures.append((label, str(e)))
                log("  FAILED: {}".format(e))
    finally:
        manifest = writer.manifest()
        writer.close(finalize=False)
    if folder_pack:
        progress(95.0, "Writing the GeoPackages...")
        manifest = _write_folder(db, out_zip, manifest, log, progress,
                                 extra_info={t[0]: {k: t[4][k] for k in ("source", "used_by")
                                                    if t[4].get(k)} for t in todo})
        if raster_todo:
            manifest = _add_rasters(out_zip, raster_todo, bbox, refresh, left_out, failures,
                                    progress, log)
        if left_out:
            manifest.setdefault("left_out", {}).update(left_out)
            _gp().write_manifest(out_zip, manifest)
        manifest["_failures"] = failures
        _report(manifest, failures, log, out_zip)
        progress(100.0, "Offline data pack written")
        return manifest
    progress(99.0, "Writing the zip\u2026")
    manifest = _write_zip(db, out_zip, manifest, log)
    ok = [k for k, v in manifest["datasets"].items() if v.get("status") == "complete"]
    total = sum(int(v.get("count") or 0) for v in manifest["datasets"].values()
                if v.get("status") == "complete")
    log("")
    log("Pack written: {} ({:.1f} MB) - {} data sets, {:,} features".format(
        out_zip, os.path.getsize(out_zip) / 1048576.0, len(ok), total))
    bad = {k: v for k, v in manifest["datasets"].items()
           if v.get("status") not in ("complete", STATUS_PARTIAL, "not available")}
    for k, v in sorted(bad.items()):
        log("  NOT in the pack: {} - {}".format(k, v.get("note") or v.get("status")))
    for k, v in sorted(manifest["datasets"].items()):
        if v.get("status") == STATUS_PARTIAL or v.get("gaps"):
            log("  INCOMPLETE (used with a warning; run again to retry): {} - {}".format(
                k, v.get("note") or "features missing"))
        elif v.get("status") == "complete" and v.get("note"):
            log("  note: {} - {}".format(k, v["note"]))
    if failures or bad:
        log("Run the same command again later to retry what failed (finished data sets "
            "are kept).")
    progress(100.0, "Offline data pack written")
    manifest["_failures"] = failures
    return manifest


def _run_one(ctx, name, label, kind, spec, bbox):
    w = ctx.writer
    if kind == "first_of":
        errors = []
        for nm, url in spec["choices"]:
            try:
                n = _run_one(ctx, nm, label, "arcgis", {"url": url}, bbox)
            except BuildCancelled:
                raise
            except _NET_ERRORS as e:
                errors.append((nm, str(e)))
                ctx.log("  {} not available ({}) - trying the next".format(nm, e))
                continue
            for old, _e in errors:          # a newer year not published: not a failure
                w.con.execute("UPDATE datasets SET status='not available', note=? "
                              "WHERE name=?", ("not published - {} used".format(nm), old))
            w.con.commit()
            return n
        raise BuildError("; ".join("{}: {}".format(a, b) for a, b in errors))
    if kind == "arcgis" and spec.get("urls"):
        errors = []
        urls = spec["urls"]
        kept = None                          # count of an incomplete result already stored
        for k, url in enumerate(urls):
            try:
                n = _run_one(ctx, name, label, "arcgis", dict(spec, url=url, urls=None), bbox)
            except BuildCancelled:
                raise
            except _NET_ERRORS as e:
                errors.append(str(e))
                ctx.log("  {} failed ({}) - trying the mirror".format(url.split("/rest/")[0],
                                                                      e))
                continue
            # v2.6.2: features missing - the mirror may have them all (if it
            # fails, the incomplete result stays in the pack)
            if ctx.status != "complete" and k + 1 < len(urls):
                kept = n
                errors.append("incomplete")
                ctx.log("  {} incomplete - trying the mirror".format(url.split("/rest/")[0]))
                ctx.status, ctx.gaps = "complete", []
                continue
            return n
        if kept is not None:
            ctx.log("  the mirror failed too - the incomplete download is kept")
            return kept
        raise BuildError("; ".join(errors))
    if kind == "local_gpkg":
        # 2.18.66: a local file - read whole on every run (no chunks, nothing to resume)
        w.begin(name, label, os.path.abspath(spec["path"]), resume=False,
                signature=_signature(kind, spec, bbox))
        ctx.status, ctx.gaps = "complete", []
        try:
            note = fetch_local_gpkg(ctx, spec)
        except BaseException as e:
            w.fail(name, str(e) if isinstance(e, BuildError) else "interrupted")
            raise
        return w.finish(note, status="complete")
    url = spec.get("url") or (C.NSI_API_URL if kind == "nsi" else C.OVERPASS_URL)
    if kind == "abi":                        # packbuild 1.1: one file per layer, no chunks
        from . import abi as A
        url = A.url_of(spec)
    # v2.8.0: continue the chunks an interrupted run stored (not with --refresh)
    kept = w.begin(name, label, url, resume=not getattr(ctx, "refresh", False) and kind != "abi",
                   signature=_signature(kind, spec, bbox))
    if kept:
        ctx.log("  continuing an interrupted download: {} finished chunk(s) kept, {:,} "
                "features".format(kept, w.count))
        started = w.stage_started(name)              # BP.2: how old the kept chunks are
        if started:
            try:
                age_h = (time.time() - time.mktime(time.strptime(
                    started, "%Y-%m-%dT%H:%M:%S"))) / 3600.0
                ctx.log("  the kept chunks were started {} ({:.1f} h ago){}".format(
                    started, age_h, " - consider --refresh" if age_h > 24 * 7 else ""))
            except (ValueError, OverflowError):
                ctx.log("  the kept chunks were started {}".format(started))
    ctx.status, ctx.gaps = "complete", []
    ctx.tiled = None                         # 1.3: arcgis_tiled per-area report
    net = NetSession(label, ctx.workers, log=ctx.log, on_beat=getattr(ctx, "beat", None))
    token = _NET.set(net)
    try:
        if kind == "nsi":
            note = fetch_nsi(ctx, bbox)
        elif kind == "arcgis":
            note = fetch_arcgis(ctx, url, bbox, spec.get("fields", "*"),
                                spec.get("precision"), spec.get("transform"),
                                spec.get("id_grid", 1), spec.get("tile_deg"))
        elif kind == "osm":
            note = fetch_osm(ctx, bbox, spec["query"], spec["parse"])
        elif kind == "arcgis_tiled":
            note = fetch_arcgis_tiled(ctx, url, bbox, spec)
        elif kind == "abi":
            note = fetch_abi(ctx, bbox, spec)
        else:
            raise BuildError("unknown kind " + kind)
    except BuildCancelled:
        w.fail(name, "interrupted")
        raise
    except _NET_ERRORS as e:
        w.fail(name, str(e))
        raise
    except BaseException:
        w.fail(name, "interrupted")
        raise
    finally:
        _NET.reset(token)
    if net.pushbacks:
        ctx.log("  the service pushed back {} time(s) (HTTP 429 / 503 / 504 or timeouts)".format(
            net.pushbacks))
    return w.finish(note or "", status=ctx.status, gaps=ctx.gaps)


def _signature(kind, spec, bbox):
    """What must be equal for stored chunks of an interrupted run to be
    reused: the settings that change what a chunk holds."""
    if kind == "arcgis":
        tr = spec.get("transform")
        return "arcgis|{}|{}{}".format(spec.get("fields", "*"), spec.get("precision"),
                                       "|" + tr.__name__ if tr is not None else "")
    if kind == "arcgis_tiled":
        f = spec.get("fill") or {}
        return "arcgis_tiled|{}|{}|{}|{}|{}|{}".format(
            spec.get("fields", "*"), spec.get("precision"), spec.get("tile_deg"),
            spec.get("tag"), f.get("url"), f.get("fields", "*"))
    if kind == "local_gpkg":
        return "local_gpkg|{}|{}".format(spec.get("layer"), _df().file_date(spec["path"]))
    if kind == "nsi":
        return "nsi|{}".format(_nsi_tile_deg())
    if kind == "abi":
        return "abi|{}|{}".format(spec.get("mode"), spec.get("kind"))
    if kind == "osm":
        try:
            q = spec["query"](tuple(bbox))
            return "osm|{}|{:08x}".format(OVERPASS_TILE_DEG,
                                          zlib.crc32(str(q).encode("utf-8")) & 0xffffffff)
        except Exception:
            return "osm|{}".format(OVERPASS_TILE_DEG)
    return kind


def _gp():
    from . import gpkgpack as GP
    return GP


def _add_layer_files(pack, file_todo, bbox, extra_folders, refresh, left_out, progress, log):
    """1.19.0: the DWR / HIFLD layer files into the pack folder (before the downloads). Returns the
    entries to download instead (the DWR dams from the DWR service when there is no file)."""
    GP = _gp()
    from . import suitedata as SD
    try:
        data = SD.data_folder()
    except Exception:                                            # noqa
        data = ""
    extra = [extra_folders] if isinstance(extra_folders, str) else list(extra_folders or [])
    try:
        saved = SD.layer_files_folder()
    except Exception:                                            # noqa
        saved = ""
    folders = PF.folders_for(data, extra + ([saved] if saved else []))
    progress(0.0, "Looking for the DWR / HIFLD layer files...")
    log("Layer files (DWR exports, HIFLD downloads): searching {}".format(
        ", ".join(folders) or "no folder (set the suite data folder, or use --files)"))
    found = PF.scan(folders)
    names = {t[0] for t in file_todo}
    for n, p in sorted(found.items()):
        if n in names:
            log("  found {}: {}".format(n, p))
    added, problems = PF.add_files(pack, found, bbox=bbox, only=names, replace=refresh, log=log)
    have = (GP.read_manifest(pack) or {}).get("datasets") or {}
    fallback = []
    for name, label, group, _k, spec in file_todo:
        if name in added or (name in have and name not in problems):
            continue
        if name in problems:
            log("  {}: NOT added - {}".format(name, problems[name]))
        fb = spec.get("fallback")
        if fb and name not in have:
            log("  {}: no usable file - the public service is used".format(name))
            fallback.append((name, label + " (public service)", group, "arcgis", fb))
        elif name not in have:
            left_out[name] = problems.get(name) or PF.missing_text(name)
            log("  {}: not in the pack - {}".format(name, left_out[name]))
    return fallback


def _add_osm_files(pack, todo, bbox, extra_folders, refresh, progress, log):
    """The OpenStreetMap layers (OSM_*) that exist as files - made from a Geofabrik extract by the
    ND Data Updater (its osm_layers folder) or nd_osm_download.py - go into the pack from the file;
    the Overpass API (which answers HTTP 429 / 504 for state-sized requests) is tried only for
    the others. The suite data folder's osm_layers/, --files and the Layer files folder are
    searched. Returns `todo` without the data sets the files supplied."""
    from . import suitedata as SD
    try:
        data = SD.data_folder()
    except Exception:                                            # noqa
        data = ""
    extra = [extra_folders] if isinstance(extra_folders, str) else list(extra_folders or [])
    try:
        saved = SD.layer_files_folder()
    except Exception:                                            # noqa
        saved = ""
    folders = PF.folders_for(data, extra + ([saved] if saved else []))
    names = {t[0] for t in todo} & set(PF.OSM_NAMES)
    found = {k: v for k, v in PF.scan(folders).items() if k in names}
    if not found:
        return todo
    progress(0.0, "Reading the OpenStreetMap layer files...")
    for n, p in sorted(found.items()):
        log("  found {}: {}".format(n, p))
    added, problems = PF.add_files(pack, found, bbox=bbox, only=names, replace=refresh, log=log)
    have = (_gp().read_manifest(pack) or {}).get("datasets") or {}
    for n, msg in sorted(problems.items()):
        log("  {}: NOT added from the file - {}; the Overpass API is tried".format(n, msg))
    return [t for t in todo if not (t[0] in found and (t[0] in added or (
        t[0] in have and t[0] not in problems)))]


def _add_3dhp_bulk(pack, todo, bbox, extra_folders, refresh, progress, log):
    """1.19.0: when the 3DHP national file (National Map download; the suite data folder's 3dhp/
    folder, or --files) is at hand, the flowlines and waterbodies are cut out of it - the web
    service answers HTTP 504 / 502 to state-sized requests. Returns `todo` without the data sets
    the file supplied; a missing file or a failure leaves them to the web service."""
    from . import suitedata as SD
    try:
        data = SD.data_folder()
    except Exception:                                            # noqa
        data = ""
    extra = [extra_folders] if isinstance(extra_folders, str) else list(extra_folders or [])
    try:
        saved = SD.layer_files_folder()
    except Exception:                                            # noqa
        saved = ""
    path = PF.scan_3dhp(PF.folders_3dhp(data, extra + ([saved] if saved else [])))
    if not path:
        return todo
    names = {t[0] for t in todo} & {"3DHP_flowlines", "3DHP_waterbodies"}
    log("3DHP national file found: {} - the flowlines and waterbodies are cut out of it".format(
        path))
    progress(0.0, "Cutting the 3DHP flowlines and waterbodies out of {}...".format(
        os.path.basename(path)))
    added, problems = PF.add_3dhp(pack, path, bbox=bbox, only=names, replace=refresh, log=log)
    have = (_gp().read_manifest(pack) or {}).get("datasets") or {}
    for n, msg in sorted(problems.items()):
        log("  {}: NOT added from the file - {}; the web service is tried".format(n, msg))
    return [t for t in todo if not (t[0] in names and (t[0] in added or (
        t[0] in have and t[0] not in problems)))]


def _nlcd_tiles(box, step):
    x0, y0, x1, y1 = box
    nx, ny = int(math.ceil((x1 - x0) / step)), int(math.ceil((y1 - y0) / step))
    for j in range(ny):
        for i in range(nx):
            yield (x0 + i * step, y0 + j * step, min(x1, x0 + (i + 1) * step),
                   min(y1, y0 + (j + 1) * step))


def _add_rasters(pack, raster_todo, bbox, refresh, left_out, failures, progress, log):
    """1.19.0: the NLCD 2021 land cover (MRLC web coverage service, 30 m, EPSG:5070) as a
    GeoPackage raster of the pack: the state's box fetched in 90 km tiles and joined. Needs GDAL
    (QGIS has it)."""
    GP = _gp()
    from . import services as SV
    from . import terrain_cache as TC
    man = GP.load_or_new(pack, bbox)
    for name, label, _g, _k, spec in raster_todo:
        if name in (man.get("rasters") or {}) and not refresh:
            log("[raster] {}: already in the pack (kept - --refresh fetches it again)".format(name))
            continue
        log("[raster] {}".format(label))
        try:
            from osgeo import gdal, osr                          # noqa
        except ImportError:
            left_out[name] = "needs GDAL to write a raster: run the build inside QGIS"
            log("  NOT built - " + left_out[name])
            continue
        service = next((s for s in SV.BUILTIN if s["id"] == spec.get("service")), None)
        if service is None:
            left_out[name] = "no land-cover service in the services list"
            continue
        t0 = time.time()
        try:
            _fetch_nlcd(pack, man, name, label, service, bbox, spec, gdal, osr, SV, TC,
                        progress, log)
            log("  done in {:.0f} s".format(time.time() - t0))
        except BuildCancelled:
            raise
        except Exception as e:                                   # noqa - report, go on
            failures.append((label, str(e)))
            log("  FAILED: {}".format(e))
    GP.write_manifest(pack, man)
    return man


def _fetch_nlcd(pack, man, name, label, service, bbox, spec, gdal, osr, SV, TC, progress, log):
    import tempfile
    src = osr.SpatialReference()
    src.ImportFromEPSG(4326)
    dst = osr.SpatialReference()
    dst.ImportFromEPSG(5070)
    for s in (src, dst):
        try:
            s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        except AttributeError:
            pass
    tr = osr.CoordinateTransformation(src, dst)
    xs, ys = [], []
    x0, y0, x1, y1 = bbox
    for k in range(21):                      # the box's edge, so the curved edges are covered
        f = k / 20.0
        for lon, lat in ((x0 + f * (x1 - x0), y0), (x0 + f * (x1 - x0), y1),
                         (x0, y0 + f * (y1 - y0)), (x1, y0 + f * (y1 - y0))):
            px, py, _z = tr.TransformPoint(lon, lat)
            xs.append(px)
            ys.append(py)
    cell = 30.0
    box = TC.snap((min(xs), min(ys), max(xs), max(ys)), cell)
    tiles = list(_nlcd_tiles(box, 3000 * cell))
    log("  {:.0f} x {:.0f} km in {} tiles".format((box[2] - box[0]) / 1000, (box[3] - box[1]) / 1000,
                                                 len(tiles)))
    work = tempfile.mkdtemp(prefix="nd_nlcd_")
    parts = []
    try:
        for i, t in enumerate(tiles):
            _check_cancel()
            size = (int(round((t[2] - t[0]) / cell)), int(round((t[3] - t[1]) / cell)))
            url = SV.wcs_coverage_url(service, t, size)
            progress(96.0 + 3.0 * i / len(tiles), "{}: tile {} of {}".format(label, i + 1,
                                                                             len(tiles)))
            p = os.path.join(work, "t{:03d}.tif".format(i))
            data = None
            for attempt in range(RETRIES):
                try:
                    req = Request(url, headers={"User-Agent": _ua()})
                    with urlopen(req, timeout=TIMEOUT_S) as r:
                        data = r.read()
                    if data[:4] in (b"II*\x00", b"MM\x00*"):
                        break
                    raise BuildError("the land-cover service sent no GeoTIFF: {!r}".format(
                        bytes(data[:80])))
                except _NET_ERRORS as e:
                    data = None
                    if attempt + 1 >= RETRIES:
                        raise BuildError("land-cover tile {}: {}".format(i + 1, _short(e)))
                    time.sleep(_backoff_s("error", attempt))
            with open(p, "wb") as fh:
                fh.write(data)
            parts.append(p)
        vrt = os.path.join(work, "nlcd.vrt")
        gdal.BuildVRT(vrt, parts)
        tif = os.path.join(work, "nlcd.tif")
        gdal.Translate(tif, vrt, format="GTiff", creationOptions=["COMPRESS=LZW", "TILED=YES"])
        info = {"label": label, "source": spec.get("source") or "", "url": service["url"],
                "fetched": time.strftime("%Y-%m-%d"), "used_by": spec.get("used_by") or ""}
        _gp().add_raster_file(pack, man, name, tif, info, log)
    finally:
        import shutil
        shutil.rmtree(work, ignore_errors=True)


def _write_folder(db, folder, manifest, log, progress=None, extra_info=None):
    """2.24.0: the data sets of the working file as the pack folder's GeoPackages - those the
    folder lacks or holds from an older fetch; the rest stay as they are.

    1.5.0: the folder's own copy is kept, never overwritten or dropped, when it is the better
    one. That is a layer the user replaced with their own file (``replaced``), a layer the folder
    holds with a fetch date at least as new as the working file's (the 3DHP flowlines /
    waterbodies cut straight to the folder from the National Map file, or an OSM file layer), and
    any usable folder copy when this run's fetch of that layer failed (status not usable). Before,
    every such layer was rewritten from the working file, so the user's own file and the 3DHP cut
    were silently put back and a failed re-fetch dropped a good layer out of the pack."""
    GP = _gp()
    have = (GP.read_manifest(folder) or {}).get("datasets") or {}

    def _folder_has(h):
        return bool(h) and os.path.isfile(os.path.join(folder, *(h.get("file") or "?").split("/")))

    todo = set()
    kept = []
    for name, v in (manifest.get("datasets") or {}).items():
        h = have.get(name) or {}
        work_usable = v.get("status") in ("complete", STATUS_PARTIAL)
        if not _folder_has(h):
            # the folder lacks it: write it from the work file, or (when this run could not fetch
            # it either) let convert_v1 record it under left_out so LAYERS.txt says it is missing
            todo.add(name)
            continue
        # the folder already holds a usable copy of this layer
        if h.get("replaced"):
            kept.append("{} (your own file)".format(name)); continue
        if not work_usable:
            kept.append("{} (this run's fetch failed; the pack keeps the copy it had)".format(name))
            continue
        if h.get("fetched") == v.get("fetched") and h.get("count") == v.get("count"):
            continue                           # identical: nothing to write
        if (h.get("fetched") or "") >= (v.get("fetched") or ""):
            kept.append("{} (the pack's copy is newer)".format(name)); continue
        todo.add(name)                         # the work file's copy is genuinely newer
    for k in kept:
        log("  kept the pack's own copy of " + k)
    log("Writing {} data set(s) to {} (one GeoPackage each)...".format(len(todo), folder))
    sub = (lambda p, m="": progress(95.0 + 4.0 * p / 100.0, "GeoPackages: " + m)) \
        if progress else None
    man = GP.convert_v1(db, folder, only=todo, log=log, progress=sub, extra_info=extra_info)
    # 1.19.0: the 3DHP layers replace the NHD ones of an earlier pack
    for old, new in (("NHD_flowlines", "3DHP_flowlines"), ("NHD_waterbodies", "3DHP_waterbodies")):
        if new in (man.get("datasets") or {}) and old in (man.get("datasets") or {}):
            GP.remove_dataset(folder, man, old, "replaced by {} (USGS 3DHP) on {}".format(
                new, time.strftime("%Y-%m-%d")))
            log("  {} removed: {} replaces it".format(old, new))
            GP.write_manifest(folder, man)
    return man


def _report(manifest, failures, log, out):
    ds = manifest.get("datasets") or {}
    total = sum(int(v.get("count") or 0) for v in ds.values())
    log("")
    log("Pack written: {} - {} layers, {:,} features (LAYERS.txt lists each layer and its "
        "source)".format(out, len(ds), total))
    for k, v in sorted((manifest.get("left_out") or {}).items()):
        log("  NOT in the pack: {} - {}".format(k, v))
    for k, v in sorted(ds.items()):
        if v.get("status") == STATUS_PARTIAL or v.get("gaps"):
            log("  INCOMPLETE (used with a warning; run again to retry): {} - {}".format(
                k, v.get("note") or "features missing"))
    if failures:
        log("Run the same command again later to retry what failed (finished data sets "
            "are kept).")


def _write_zip(db, out_zip, manifest, log):
    # a clean single file (no -wal beside it) goes in the zip
    w = PackWriter(db, tuple(manifest["bbox"]))
    manifest = w.manifest()
    leftovers = w.stage_leftovers() or w.has_chunks()
    w.close(finalize=True)
    manifest = dict(manifest)
    src = db
    if leftovers:
        # v2.8.0: the chunks of interrupted / failed data sets stay in the work file
        # (the next run continues with them) but do not go into the zip
        src = write_clean_copy(db, db + ".zipcopy")
    tmp = out_zip + ".part"
    readme = ("ND Dam Hazard Classification Helper - offline data pack\n\n"
              "Built {} for {} (lon / lat {}).\n\n"
              "On the offline computer: plugin > Data & Output tab > 7. Offline data pack > "
              "Browse..., pick this zip (it is unpacked once, next to the zip or in your "
              "home folder), and tick 'Offline only'.\n\nData sets (name: features, fetched "
              "on):\n{}\n").format(
        manifest.get("created"), manifest.get("area"), manifest.get("bbox"),
        "\n".join("  {}: {} {}{}".format(
            k, v.get("count"), v.get("fetched") or "",
            " - INCOMPLETE ({})".format(v.get("note")) if (
                v.get("status") == STATUS_PARTIAL or v.get("gaps")) else
            "" if v.get("status") == "complete" else
            " - not available ({})".format(v.get("note")) if v.get("status") == "not available"
            else " - NOT INCLUDED ({})".format(v.get("note")))
            for k, v in sorted(manifest["datasets"].items())))
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        z.writestr(MANIFEST_NAME, json.dumps(manifest, indent=2))
        z.writestr("README.txt", readme)
        z.write(src, DB_NAME)
    if src != db:
        try:
            os.remove(src)
        except OSError:
            pass
    os.replace(tmp, out_zip)
    with open(os.path.join(os.path.dirname(db), MANIFEST_NAME), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)
    return manifest


def main(argv=None):
    nd = pack_layers() == "nd"
    ap = argparse.ArgumentParser(
        description="Build the {} offline data pack (North Dakota).".format(
            "ND Dam Suite" if nd else "DamSafety"))
    ap.add_argument("--out", default="ND_Dam_Suite_Pack" if nd else "nd_offline_pack.zip",
                    help="pack folder to write (one GeoPackage per layer), or a .zip for the "
                         "one-file pack" if nd else "zip to write")
    ap.add_argument("--pad", type=float, default=DEFAULT_PAD_DEG,
                    help="margin around North Dakota's bounding box, degrees (default "
                         "%(default)s; 0 = the box itself)")
    ap.add_argument("--only", help="data sets or groups to fetch, comma separated")
    ap.add_argument("--skip", help="data sets or groups to leave out, comma separated")
    ap.add_argument("--refresh", action="store_true",
                    help="fetch again data sets that are already in the pack (and do not "
                         "continue interrupted downloads: everything is read again)")
    ap.add_argument("--workers", type=int, default=None,
                    help="requests at once (default {})".format(C.DOWNLOAD_WORKERS))
    ap.add_argument("--sources", help="the plugin's data-source file (JSON) to use its "
                                      "addresses")
    ap.add_argument("--files", action="append", default=None,
                    help="a folder with the DWR / HIFLD layer files (can be repeated; the suite "
                         "data folder's dwr/ and hifld/ are searched too)")
    ap.add_argument("--box", help="build a pack for another area: xmin,ymin,xmax,ymax in lon / lat "
                                  "(default: North Dakota plus --pad)")
    ap.add_argument("--download-dwr", metavar="FOLDER",
                    help="download the four ND DWR layers (dams, dam lines, "
                         "dugouts, dugout polygons) as shapefile zips from "
                         "mapservice.dwr.nd.gov into FOLDER, then exit")
    ap.add_argument("--dwr-bbox", metavar="W,S,E,N",
                    help="2.19.2: with --download-dwr: only this lon / lat box, written "
                         "with = (--dwr-bbox=-100.85,46.75,-100.70,46.85; default: the "
                         "full data sets)")
    ap.add_argument("--dwr-format", choices=sorted(DWR_FORMATS), default="shp",
                    help="2.19.2: with --download-dwr: shp (shapefile) or spat "
                         "(SpatiaLite, full field names)")
    ap.add_argument("--dwr-folder", metavar="PATH",
                    help="2.18.66: a folder with the ND DWR GeoPackages (DWR_Dams.gpkg, "
                         "DWR_Dam_Lines.gpkg, DWR_Unknown_Structures.gpkg, DWR_Dugouts.gpkg, "
                         "DWR_Dugouts_Polygons.gpkg): adds them as the data sets DWR_dams, "
                         "DWR_dam_lines, DWR_unknown_structures, DWR_dugouts, "
                         "DWR_dugout_polygons (group dwr; all attributes, reprojected to "
                         "lon / lat). --only dwr builds just these.")
    ap.add_argument("--list", action="store_true", help="list the data sets and stop")
    a = ap.parse_args(argv)
    if a.download_dwr:
        bbox = None
        if a.dwr_bbox:
            try:
                bbox = tuple(float(v) for v in a.dwr_bbox.split(","))
                assert len(bbox) == 4 and bbox[0] < bbox[2] and bbox[1] < bbox[3]
            except (ValueError, AssertionError):
                print("ERROR: --dwr-bbox needs west,south,east,north in degrees")
                return 1
        got = download_dwr_shapefiles(a.download_dwr, log=print, bbox=bbox, fmt=a.dwr_format)
        print("{} of {} DWR layer(s) downloaded".format(len(got), len(DWR_DOWNLOADS)))
        return 0 if len(got) == len(DWR_DOWNLOADS) else 1
    if a.list:
        try:
            table = datasets(a.dwr_folder)
        except BuildError as e:
            print("ERROR: {}".format(e))
            return 1
        for name, label, group, kind, spec in table:
            src = spec.get("path") and "{} | {}".format(spec["path"], spec["layer"]) or \
                spec.get("url") or ", ".join(spec.get("urls") or []) or \
                ", ".join(u for _n, u in spec.get("choices") or []) or \
                ("a file in dwr/ or hifld/" + (" (else " + spec["fallback"]["url"] + ")"
                                                if spec.get("fallback") else "")
                 if kind == "file" else "MRLC web coverage service" if kind == "raster" else
                 C.NSI_API_URL if kind == "nsi" else C.OVERPASS_URL)
            print("{:<32} group {:<10} {}\n{:<32} {}".format(name, group, label, "", src))
        return 0

    last = [0.0]
    tty = sys.stdout.isatty()

    def progress(p, m):
        if tty and time.time() - last[0] > 2.0:
            last[0] = time.time()
            sys.stdout.write("\r  {:5.1f}%  {:<90.90}".format(p, m))
            sys.stdout.flush()

    def log(m):
        if tty:
            sys.stdout.write("\r" + " " * 100 + "\r")
        print(m)
        sys.stdout.flush()
    try:
        man = build(a.out, a.pad, a.only, a.skip, a.workers, a.refresh, a.sources,
                    progress, log, files=a.files, dwr_folder=a.dwr_folder,
                    box=[float(v) for v in a.box.split(",")] if a.box else None)
    except (KeyboardInterrupt, BuildCancelled):
        print("\nStopped - the finished data sets are kept; run the same command to go on.")
        return 2
    except (BuildError, PackError) as e:
        print("\nERROR: {}".format(e))
        return 1
    bad = [k for k, v in man["datasets"].items()
           if v.get("status") not in ("complete", "not available") or v.get("gaps")]
    return 1 if (man.get("_failures") or bad) else 0


if __name__ == "__main__":
    sys.exit(main())
